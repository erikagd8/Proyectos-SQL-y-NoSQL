<template>
    <div class="auth-page">

        <div class="auth-card">

            <div class="auth-logo">
                <span>S</span>
            </div>

            <p class="auth-subtitle">
                CREA TU CUENTA
            </p>

            <h1>Únete a StudySpace</h1>

            <p class="auth-description">
                Comienza a organizar tu espacio académico.
            </p>

            <form @submit.prevent="registrar">

                <div class="form-group">
                    <label>Nombre completo</label>

                    <input
                        v-model.trim="nombre"
                        type="text"
                        placeholder="Tu nombre"
                        autocomplete="name"
                        maxlength="80"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>Correo electrónico</label>

                    <input
                        v-model.trim="correo"
                        type="email"
                        placeholder="ejemplo@correo.com"
                        autocomplete="email"
                        maxlength="150"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>Contraseña</label>

                    <input
                        v-model="password"
                        type="password"
                        placeholder="Mínimo 8 caracteres"
                        autocomplete="new-password"
                        minlength="8"
                        required
                    >
                </div>

                <div class="form-group">
                    <label>Confirmar contraseña</label>

                    <input
                        v-model="confirmarPassword"
                        type="password"
                        placeholder="Repite tu contraseña"
                        autocomplete="new-password"
                        minlength="8"
                        required
                    >
                </div>

                <p v-if="error" class="error-message">
                    {{ error }}
                </p>

                <button
                    type="submit"
                    class="auth-button"
                    :disabled="cargando"
                >
                    {{ cargando ? 'Creando cuenta...' : 'Crear cuenta' }}
                </button>

            </form>

            <div class="auth-footer">
                ¿Ya tienes una cuenta?

                <RouterLink to="/login">
                    Iniciar sesión
                </RouterLink>
            </div>

        </div>

    </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { authService } from '../services/authService'

const router = useRouter()

const nombre = ref('')
const correo = ref('')
const password = ref('')
const confirmarPassword = ref('')

const error = ref('')
const cargando = ref(false)

const registrar = async () => {

    error.value = ''

    if (password.value.length < 8) {
        error.value = 'La contraseña debe tener al menos 8 caracteres.'
        return
    }

    if (password.value !== confirmarPassword.value) {
        error.value = 'Las contraseñas no coinciden.'
        return
    }

    cargando.value = true

    try {

        await authService.registrar({
            nombre: nombre.value,
            correo: correo.value,
            password: password.value
        })

        await router.replace('/')

    } catch (err) {

        error.value = err.message

    } finally {

        cargando.value = false

    }
}
</script>

<style scoped>
.auth-page {
    position: fixed;
    inset: 0;
    z-index: 10000;

    display: flex;
    justify-content: center;
    align-items: center;

    padding: 20px;

    background:
        linear-gradient(135deg, #203f36, #456b5b);

    overflow-y: auto;
}

.auth-card {
    width: 100%;
    max-width: 450px;

    padding: 35px 38px;

    background: white;
    border-radius: 22px;

    box-shadow: 0 20px 60px rgba(0,0,0,.20);
}

.auth-logo {
    width: 58px;
    height: 58px;

    margin: 0 auto 15px;

    display: grid;
    place-items: center;

    background: #e8f0e8;
    color: #315d49;

    border-radius: 16px;

    font-size: 29px;
    font-weight: 800;
}

.auth-subtitle {
    text-align: center;
    color: #78917c;
    font-size: 11px;
    letter-spacing: 2px;
    font-weight: 700;
}

h1 {
    text-align: center;
    color: #29483d;
    margin: 8px 0;
    font-size: 27px;
}

.auth-description {
    text-align: center;
    color: #78917c;
    margin-bottom: 25px;
    font-size: 13px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 7px;
    color: #29483d;
    font-size: 13px;
    font-weight: 600;
}

.form-group input {
    width: 100%;
    padding: 13px;

    border: 1px solid #dce5dc;
    border-radius: 10px;

    outline: none;
    font-size: 14px;
}

.form-group input:focus {
    border-color: #456b5b;
    box-shadow: 0 0 0 3px #456b5b20;
}

.auth-button {
    width: 100%;
    padding: 14px;

    border: none;
    border-radius: 10px;

    background: #315d49;
    color: white;

    font-weight: 700;
    font-size: 14px;

    cursor: pointer;
}

.auth-button:hover {
    background: #203f36;
}

.auth-button:disabled {
    opacity: .6;
    cursor: not-allowed;
}

.auth-footer {
    margin-top: 22px;
    text-align: center;
    color: #718078;
    font-size: 13px;
}

.auth-footer a {
    color: #315d49;
    font-weight: 700;
    text-decoration: none;
    margin-left: 4px;
}

.error-message {
    padding: 10px;
    margin-bottom: 15px;

    background: #fff0f0;
    color: #c0392b;

    border-radius: 8px;
    font-size: 13px;
}
</style>