
<template>
    <main class="dashboard">

        <!-- ENCABEZADO DE BIENVENIDA -->
        <section class="welcome">
            <div class="welcome-content">
                <span class="eyebrow">TU ESPACIO PERSONAL</span>
                <h1>{{ saludo }}, bienvenida a StudySpace</h1>

                <div class="welcome-date">
                    <span>◷</span>
                    {{ fechaActual }}
                </div>
            </div>
        </section>

        <!-- RESUMEN -->
        <section class="section-block">

            <div class="section-heading">
                <div>
                    <span class="eyebrow">TU ORGANIZACIÓN</span>
                    <h2>Tu resumen académico</h2>
                    <p>Así va tu organización actualmente.</p>
                </div>
                <span class="live-indicator">
                    <i></i> Datos actualizados
                </span>
            </div>

            <div class="stats-grid">

                <article class="stat-card">
                    <div class="stat-top">
                        <div class="stat-icon green">▤</div>
                        <span class="stat-label">ASIGNATURAS</span>
                    </div>
                    <strong>{{ resumen.materias }}</strong>
                    <p>Materias registradas</p>
                    <div class="stat-bottom">
                        <span>Materias activas</span>
                        <b>{{ resumen.materiasActivas }}</b>
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <div class="stat-icon orange">✓</div>
                        <span class="stat-label">PENDIENTES</span>
                    </div>
                    <strong>{{ resumen.pendientes }}</strong>
                    <p>Actividades por comenzar</p>
                    <div class="stat-bottom">
                        <span>Por entregar</span>
                        <b>{{ resumen.pendientes }}</b>
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <div class="stat-icon blue">↗</div>
                        <span class="stat-label">EN PROGRESO</span>
                    </div>
                    <strong>{{ resumen.enProgreso }}</strong>
                    <p>Actividades en desarrollo</p>
                    <div class="stat-bottom">
                        <span>En desarrollo</span>
                        <b>{{ resumen.enProgreso }}</b>
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <div class="stat-icon purple">✦</div>
                        <span class="stat-label">COMPLETADAS</span>
                    </div>
                    <strong>{{ resumen.completadas }}</strong>
                    <p>Actividades terminadas</p>
                    <div class="stat-bottom">
                        <span>Finalizadas</span>
                        <b>{{ porcentajeCompletado }}%</b>
                    </div>
                </article>

            </div>
        </section>

        <!-- CONTENIDO INFERIOR -->
        <section class="dashboard-grid">

        </section>

    </main>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const API = 'http://localhost:3000/api'

const periodos = ref([])
const materias = ref([])
const tareas = ref([])
const errorCarga = ref('')

const ahora = new Date()

const fechaActual = computed(() => {
    return ahora.toLocaleDateString('es-MX', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
})

const saludo = computed(() => {
    const hora = new Date().getHours()

    if (hora < 12) return 'Buenos días'
    if (hora < 19) return 'Buenas tardes'
    return 'Buenas noches'
})

const periodoActivo = computed(() => {
    return periodos.value.find(p => p.estado === 'Activo')
})

const periodoActual = computed(() => {
    return periodoActivo.value?.nombre || 'Sin periodo seleccionado'
})

const periodoDescripcion = computed(() => {
    if (!periodoActivo.value) {
        return 'Registra o activa un periodo para organizar tus estudios.'
    }

    return `${periodoActivo.value.tipo} ${periodoActivo.value.numero} · Tu espacio académico actual.`
})

const resumen = computed(() => ({
    materias: materias.value.length,

    materiasActivas: materias.value.filter(
        m => m.estado === 'Activa'
    ).length,

    pendientes: tareas.value.filter(
        t => t.estado === 'Pendiente'
    ).length,

    enProgreso: tareas.value.filter(
        t => t.estado === 'En progreso'
    ).length,

    completadas: tareas.value.filter(
        t => t.estado === 'Completada'
    ).length
}))

const porcentajeCompletado = computed(() => {
    const total = tareas.value.length

    if (!total) return 0

    return Math.round(
        (resumen.value.completadas / total) * 100
    )
})

const proximasTareas = computed(() => {
    const hoy = new Date()
    hoy.setHours(0, 0, 0, 0)

    return tareas.value
        .filter(t => {
            if (!t.fechaEntrega || t.estado === 'Completada') {
                return false
            }

            const fecha = new Date(t.fechaEntrega)
            fecha.setHours(0, 0, 0, 0)

            return fecha >= hoy
        })
        .sort((a, b) =>
            new Date(a.fechaEntrega) - new Date(b.fechaEntrega)
        )
        .slice(0, 4)
})

const obtenerDia = fecha => {
    return new Date(fecha).getDate()
}

const obtenerMes = fecha => {
    return new Date(fecha).toLocaleDateString('es-MX', {
        month: 'short'
    }).replace('.', '')
}

const clasePrioridad = prioridad => {
    return {
        Alta: 'high',
        Media: 'medium',
        Baja: 'low'
    }[prioridad] || 'medium'
}

const cargarDatos = async () => {
    errorCarga.value = ''

    try {
        const [respuestaPeriodos, respuestaMaterias, respuestaTareas] =
            await Promise.all([
                fetch(`${API}/periodos`),
                fetch(`${API}/materias`),
                fetch(`${API}/tareas`)
            ])

        if (
            !respuestaPeriodos.ok ||
            !respuestaMaterias.ok ||
            !respuestaTareas.ok
        ) {
            throw new Error('No fue posible consultar todos los datos.')
        }

        const [datosPeriodos, datosMaterias, datosTareas] =
            await Promise.all([
                respuestaPeriodos.json(),
                respuestaMaterias.json(),
                respuestaTareas.json()
            ])

        periodos.value = datosPeriodos.periodos || []
        materias.value = datosMaterias.materias || []
        tareas.value = datosTareas.tareas || []

    } catch (error) {
        errorCarga.value =
            'No se pudieron actualizar algunos datos. Comprueba que el servidor esté funcionando.'

        console.error('Error en dashboard:', error)
    }
}

onMounted(cargarDatos)
</script>

<style scoped>
.dashboard {
    max-width: 1500px;
    margin: auto;
    padding: 42px 40px;
    color: #29483d;
}

/* GENERAL */

.eyebrow {
    display: block;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.5px;
    color: #78917c;
}

.section-block {
    margin-top: 38px;
}

.section-heading {
    display: flex;
    justify-content: space-between;
    align-items: end;
    gap: 15px;
    margin-bottom: 20px;
}

.section-heading h2,
.panel-heading h2 {
    margin: 7px 0;
    font-size: 21px;
    color: #29483d;
}

.section-heading p {
    color: #87958c;
    font-size: 13px;
    margin: 0;
}

/* BIENVENIDA */

.welcome {
    min-height: 225px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #e8efe8;
    border-radius: 18px;
    padding: 34px 40px;
    position: relative;
    overflow: hidden;
}

.welcome-content {
    position: relative;
    z-index: 2;
    max-width: 650px;
}

.welcome h1 {
    font-size: clamp(24px, 3vw, 34px);
    margin: 1px 0;
    color: #29483d;
    line-height: 1.25;
}

.welcome h1 span {
    font-size: 27px;
}

.welcome-content > p {
    color: #758b7e;
    font-size: 14px;
    line-height: 1.7;
}

.welcome-date {
    margin-top: 22px;
    display: inline-flex;
    align-items: center;
    gap: 9px;
    background: white;
    padding: 10px 15px;
    border-radius: 9px;
    color: #587b68;
    font-size: 12px;
    text-transform: capitalize;
}

.welcome-art {
    width: 230px;
    height: 190px;
    position: relative;
    flex-shrink: 0;
}

.art-circle {
    position: absolute;
    border-radius: 50%;
}

.circle-one {
    width: 175px;
    height: 175px;
    background: #d2e1d3;
    right: 10px;
    top: 5px;
}

.circle-two {
    width: 115px;
    height: 115px;
    background: #b5cbb8;
    right: 40px;
    top: 35px;
}

.art-leaf {
    position: absolute;
    right: 66px;
    top: 43px;
    font-size: 85px;
    color: #456e56;
}

.art-star {
    position: absolute;
    right: 0;
    top: 10px;
    font-size: 30px;
    color: #829b77;
}

.art-number {
    position: absolute;
    right: 0;
    bottom: 0;
    color: #78917c;
    font-size: 12px;
    letter-spacing: 3px;
}

/* PERIODO */

.period-card {
    margin-top: 22px;
    padding: 23px 27px;
    border-radius: 15px;
    background: #426b59;
    color: white;
    display: flex;
    align-items: center;
    gap: 19px;
}

.period-icon {
    width: 48px;
    height: 48px;
    display: grid;
    place-items: center;
    border-radius: 12px;
    background: rgba(255,255,255,.14);
    font-size: 24px;
}

.period-info {
    flex: 1;
}

.period-info > span {
    font-size: 10px;
    letter-spacing: 1.3px;
    color: #d0e0d3;
}

.period-info h2 {
    font-size: 20px;
    margin: 6px 0;
}

.period-info p {
    margin: 0;
    font-size: 12px;
    color: #d7e4d9;
}

.period-button {
    background: white;
    color: #426b59;
    padding: 12px 17px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
    text-decoration: none;
}

/* ESTADÍSTICAS */

.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
}

.stat-card {
    background: white;
    border: 1px solid #e3eae2;
    border-radius: 14px;
    padding: 21px;
    min-width: 0;
}

.stat-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.stat-icon,
.quick-icon {
    width: 39px;
    height: 39px;
    display: grid;
    place-items: center;
    border-radius: 11px;
    font-size: 20px;
}

.green { background: #e4eee5; color: #527c5b; }
.orange { background: #f9eae2; color: #c77e56; }
.blue { background: #e5eef3; color: #60899e; }
.purple { background: #eee9f5; color: #8675a2; }

.stat-label {
    font-size: 9px;
    letter-spacing: 1px;
    color: #93a097;
    font-weight: 700;
}

.stat-card > strong {
    display: block;
    margin-top: 17px;
    font-size: 32px;
    color: #315d49;
}

.stat-card > p {
    font-size: 12px;
    color: #91a096;
    margin: 5px 0 17px;
}

.stat-bottom {
    border-top: 1px solid #edf0eb;
    padding-top: 12px;
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    color: #819188;
}

.stat-bottom b {
    color: #426b59;
}

/* PANELES */

.dashboard-grid {
    margin-top: 25px;
    display: grid;
    grid-template-columns: .85fr 1.5fr;
    gap: 18px;
}

.panel {
    background: white;
    border: 1px solid #e3eae2;
    border-radius: 15px;
    padding: 24px;
    min-width: 0;
}

.panel-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.panel-heading h2 {
    font-size: 17px;
}

.panel-symbol {
    font-size: 25px;
    color: #a3b69c;
}

.progress-content {
    margin: 28px 0;
}

.progress-number {
    display: flex;
    align-items: baseline;
    gap: 9px;
    margin-bottom: 17px;
}

.progress-number strong {
    font-size: 35px;
    color: #426b59;
}

.progress-number span {
    color: #84938a;
    font-size: 12px;
}

.progress-track {
    height: 10px;
    background: #edf1eb;
    border-radius: 20px;
    overflow: hidden;
    margin-bottom: 24px;
}

.progress-fill {
    height: 100%;
    background: #6c9576;
    border-radius: 20px;
    transition: width .4s;
}

.progress-legend {
    display: flex;
    justify-content: space-between;
    padding: 9px 0;
    color: #77877e;
    font-size: 12px;
}

.progress-legend > span:first-child {
    display: flex;
    align-items: center;
    gap: 9px;
}

.dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
}

.completed { background: #78a987; }
.pending { background: #d4a15d; }
.working { background: #78a0b6; }

.text-link,
.small-link {
    text-decoration: none;
    color: #507761;
    font-size: 12px;
    font-weight: 700;
}

.small-link {
    white-space: nowrap;
}

/* ACTIVIDADES */

.activity-list {
    margin-top: 20px;
}

.activity-item {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 14px 0;
    border-bottom: 1px solid #edf0eb;
}

.activity-item:last-child {
    border-bottom: none;
}

.activity-date {
    width: 45px;
    height: 48px;
    background: #edf3ec;
    border-radius: 9px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    flex-shrink: 0;
}

.activity-date strong {
    font-size: 17px;
    color: #426b59;
}

.activity-date span {
    font-size: 10px;
    color: #82958a;
    text-transform: uppercase;
}

.activity-info {
    flex: 1;
    min-width: 0;
}

.activity-info strong,
.activity-info span {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.activity-info strong {
    font-size: 12px;
    color: #345649;
}

.activity-info span {
    margin-top: 5px;
    font-size: 11px;
    color: #91a097;
}

.priority {
    padding: 6px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 700;
}

.high { background: #f9e6e3; color: #bd7164; }
.medium { background: #f8f0df; color: #b28c43; }
.low { background: #e5f0e7; color: #648c6b; }

.empty-activities {
    min-height: 205px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
}

.empty-activities > span {
    font-size: 30px;
    color: #a5b99f;
}

.empty-activities strong {
    font-size: 13px;
    margin-top: 10px;
}

.empty-activities p {
    font-size: 11px;
    color: #91a096;
}

.empty-activities a {
    color: #507761;
    text-decoration: none;
    font-size: 12px;
    font-weight: 700;
}

/* ACCESOS RÁPIDOS */

.quick-section {
    margin-top: 38px;
}

.quick-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.quick-card {
    display: flex;
    align-items: center;
    gap: 13px;
    background: white;
    padding: 18px;
    border: 1px solid #e3eae2;
    border-radius: 13px;
    text-decoration: none;
    transition: transform .2s, border-color .2s;
}

.quick-card:hover {
    transform: translateY(-3px);
    border-color: #a9c2ad;
}

.quick-card > div:nth-child(2) {
    flex: 1;
    min-width: 0;
}

.quick-card strong,
.quick-card span {
    display: block;
}

.quick-card strong {
    color: #345649;
    font-size: 12px;
}

.quick-card span {
    color: #91a096;
    font-size: 10px;
    margin-top: 5px;
}

.quick-card b {
    color: #78917c;
    font-size: 18px;
}

/* FRASE FINAL */

.quote-card {
    margin-top: 25px;
    display: flex;
    align-items: center;
    gap: 18px;
    background: #edf2e9;
    padding: 20px 25px;
    border-radius: 13px;
}

.quote-card > span:first-child {
    font-size: 28px;
    color: #8ca486;
}

.quote-card h3 {
    margin: 0 0 5px;
    color: #426b59;
    font-size: 15px;
}

.quote-card p {
    margin: 0;
    color: #84958a;
    font-size: 12px;
}

.quote-decoration {
    margin-left: auto;
    font-size: 27px;
}

.dashboard-footer {
    text-align: center;
    padding: 30px 0 5px;
    font-size: 9px;
    letter-spacing: 2px;
    color: #9aa99e;
}

.error-message {
    margin-top: 20px;
    padding: 13px;
    border-radius: 9px;
    background: #fae9e8;
    color: #a9534b;
    font-size: 12px;
}

/* RESPONSIVE */

@media (max-width: 1050px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .dashboard-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 700px) {
    .dashboard {
        padding: 23px 16px;
    }

    .welcome {
        padding: 27px 23px;
        min-height: 210px;
    }

    .welcome-art {
        position: absolute;
        right: -65px;
        opacity: .35;
    }

    .welcome-content {
        max-width: 100%;
    }

    .welcome h1 {
        font-size: 25px;
    }

    .period-card {
        flex-wrap: wrap;
        padding: 19px;
    }

    .period-info {
        flex-basis: calc(100% - 70px);
    }

    .period-button {
        width: 100%;
        text-align: center;
    }

    .stats-grid {
        gap: 10px;
    }

    .stat-card {
        padding: 15px;
    }

    .stat-label {
        font-size: 8px;
    }

    .section-heading h2 {
        font-size: 18px;
    }

    .live-indicator {
        display: none;
    }

    .quick-grid {
        grid-template-columns: 1fr;
    }

    .quote-card {
        padding: 17px;
    }

    .quote-decoration {
        display: none;
    }
}

@media (max-width: 380px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
}
</style>
