
<template>
    <section class="periodos-page">

        <!-- ENCABEZADO -->
        <header class="periodos-header">
            <div>
                <span class="periodos-etiqueta">ORGANIZACIÓN ACADÉMICA</span>
                <h1>Periodos académicos</h1>
                <p>Organiza tus semestres y cuatrimestres.</p>
            </div>

            <button
                class="periodos-btn-principal"
                @click="nuevoPeriodo"
            >
                + Nuevo periodo
            </button>
        </header>

        <!-- ESTADÍSTICAS -->
        <div class="periodos-estadisticas">

            <article class="periodo-stat">
                <span>Total de periodos</span>
                <strong>{{ periodos.length }}</strong>
                <small>Periodos registrados</small>
            </article>

            <article class="periodo-stat">
                <span>Activos</span>
                <strong>{{ contarEstado('Activo') }}</strong>
                <small>En curso</small>
            </article>

            <article class="periodo-stat">
                <span>Planeados</span>
                <strong>{{ contarEstado('Planeado') }}</strong>
                <small>Próximos periodos</small>
            </article>

            <article class="periodo-stat">
                <span>Finalizados</span>
                <strong>{{ contarEstado('Finalizado') }}</strong>
                <small>Periodos anteriores</small>
            </article>

        </div>

        <!-- MENSAJES -->
        <div v-if="error" class="periodos-error">
            {{ error }}
        </div>

        <div v-if="mensaje" class="periodos-exito">
            {{ mensaje }}
        </div>

        <!-- FILTROS -->
        <div class="periodos-filtros">

            <input
                v-model="busqueda"
                type="search"
                placeholder="Buscar periodo..."
            >

            <select v-model="filtroTipo">
                <option value="Todos">Todos los tipos</option>
                <option value="Semestre">Semestres</option>
                <option value="Cuatrimestre">Cuatrimestres</option>
            </select>

            <select v-model="filtroEstado">
                <option value="Todos">Todos los estados</option>
                <option value="Activo">Activos</option>
                <option value="Finalizado">Finalizados</option>
            </select>



        </div>

        <!-- TABLA -->
        <div class="periodos-tabla-contenedor">

            <div class="periodos-tabla-titulo">
                <div>
                    <h2>Mis periodos</h2>
                    <p>Consulta y administra tu historial académico.</p>
                </div>

                <span>{{ periodosFiltrados.length }} registros</span>
            </div>

            <div v-if="cargando" class="periodos-vacio">
                Cargando periodos...
            </div>

            <table v-else class="periodos-tabla">

                <thead>
                    <tr>
                        <th>Periodo</th>
                        <th>Tipo</th>
                        <th>Número</th>
                        <th>Fecha de inicio</th>
                        <th>Fecha final</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                    <tr
                        v-for="p in periodosFiltrados"
                        :key="p._id"
                    >
                        <td>
                            <strong>{{ p.nombre }}</strong>
                        </td>

                        <td>{{ p.tipo }}</td>

                        <td>{{ p.numero }}</td>

                        <td>{{ formatearFecha(p.fechaInicio) }}</td>

                        <td>{{ formatearFecha(p.fechaFin) }}</td>

                        <td>
                            <span
                                class="periodo-estado"
                                :class="'estado-' + p.estado.toLowerCase()"
                            >
                                {{ p.estado }}
                            </span>
                        </td>

                        <td class="periodos-acciones">

                            <button
                                class="periodo-btn-editar"
                                title="Editar"
                                @click="editarPeriodo(p)"
                            >
                                ✎
                            </button>

                            <button
                                class="periodo-btn-eliminar"
                                title="Eliminar"
                                @click="confirmarEliminar(p)"
                            >
                                ×
                            </button>

                        </td>
                    </tr>

                    <tr v-if="!periodosFiltrados.length">
                        <td colspan="7" class="periodos-vacio">
                            No se encontraron periodos académicos.
                        </td>
                    </tr>

                </tbody>
            </table>

        </div>

        <!-- MODAL -->
        <div
            v-if="mostrarFormulario"
            class="periodos-modal-fondo"
            @click.self="cerrarFormulario"
        >

            <form
                class="periodos-modal"
                @submit.prevent="guardarPeriodo"
            >

                <div class="periodos-modal-header">
                    <div>
                        <span class="periodos-etiqueta">
                            CONFIGURACIÓN ACADÉMICA
                        </span>

                        <h2>
                            {{ editando ? 'Editar periodo' : 'Nuevo periodo' }}
                        </h2>

                        <p>
                            Completa la información de tu periodo académico.
                        </p>
                    </div>

                    <button
                        type="button"
                        class="periodos-cerrar"
                        @click="cerrarFormulario"
                    >
                        ×
                    </button>
                </div>

                <div class="periodos-formulario">

                    <div class="periodos-campo">
                        <label>Nombre del periodo</label>

                        <input
                            v-model.trim="formulario.nombre"
                            type="text"
                            placeholder="Ej. 2026-2"
                            maxlength="50"
                            required
                        >
                    </div>

                    <div class="periodos-campo">
                        <label>Tipo de periodo</label>

                        <select v-model="formulario.tipo" required>
                            <option value="Semestre">Semestre</option>
                            <option value="Cuatrimestre">Cuatrimestre</option>
                        </select>
                    </div>

                    <div class="periodos-campo">
                        <label>Número de periodo</label>

                        <input
                            v-model.number="formulario.numero"
                            type="number"
                            min="1"
                            required
                        >
                    </div>

                    <div class="periodos-campo">
                        <label>Fecha de inicio</label>

                        <input
                            v-model="formulario.fechaInicio"
                            type="date"
                            required
                        >
                    </div>

                    <div class="periodos-campo">
                        <label>Fecha de finalización</label>

                        <input
                            v-model="formulario.fechaFin"
                            type="date"
                            :min="formulario.fechaInicio"
                            required
                        >
                    </div>

                    <div class="periodos-campo">
                        <label>Estado</label>

                        <select v-model="formulario.estado">
                            <option value="Activo">Activo</option>
                            <option value="Finalizado">Finalizado</option>
                        </select>
                    </div>

                </div>

                <div class="periodos-modal-acciones">

                    <button
                        type="button"
                        class="periodos-btn-secundario"
                        @click="cerrarFormulario"
                    >
                        Cancelar
                    </button>

                    <button
                        type="submit"
                        class="periodos-btn-principal"
                        :disabled="guardando"
                    >
                        {{ guardando ? 'Guardando...' : 'Guardar periodo' }}
                    </button>

                </div>

            </form>
        </div>

    </section>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { periodosService } from '../services/periodosService'

const periodos = ref([])
const busqueda = ref('')
const filtroTipo = ref('Todos')
const filtroEstado = ref('Todos')

const cargando = ref(false)
const guardando = ref(false)

const error = ref('')
const mensaje = ref('')

const mostrarFormulario = ref(false)
const editando = ref(false)
const idEdicion = ref(null)

const formulario = ref({
    nombre: '',
    tipo: 'Semestre',
    numero: 1,
    fechaInicio: '',
    fechaFin: '',
    estado: 'Activo'
})

// FILTRAR PERIODOS
const periodosFiltrados = computed(() => {

    return periodos.value.filter(p => {

        const coincideNombre = p.nombre
            .toLowerCase()
            .includes(busqueda.value.toLowerCase())

        const coincideTipo =
            filtroTipo.value === 'Todos' ||
            p.tipo === filtroTipo.value

        const coincideEstado =
            filtroEstado.value === 'Todos' ||
            p.estado === filtroEstado.value

        return coincideNombre && coincideTipo && coincideEstado
    })
})

// CONTAR POR ESTADO
function contarEstado(estado) {
    return periodos.value.filter(p => p.estado === estado).length
}

// FORMATEAR FECHAS
function formatearFecha(fecha) {

    if (!fecha) return '-'

    const [anio, mes, dia] = String(fecha)
        .slice(0, 10)
        .split('-')

    return `${dia}/${mes}/${anio}`
}

// CARGAR PERIODOS
async function cargarPeriodos() {

    cargando.value = true
    error.value = ''

    try {

        const datos = await periodosService.obtenerTodos()

        periodos.value = datos.periodos

    } catch (e) {

        error.value = e.message

    } finally {

        cargando.value = false

    }
}

// LIMPIAR FORMULARIO
function limpiarFormulario() {

    formulario.value = {
        nombre: '',
        tipo: 'Semestre',
        numero: 1,
        fechaInicio: '',
        fechaFin: '',
        estado: 'Activo'
    }

    idEdicion.value = null
    editando.value = false
}

// NUEVO PERIODO
function nuevoPeriodo() {

    limpiarFormulario()
    error.value = ''
    mensaje.value = ''

    mostrarFormulario.value = true
}

// EDITAR PERIODO
function editarPeriodo(p) {

    editando.value = true
    idEdicion.value = p._id

    formulario.value = {
        nombre: p.nombre,
        tipo: p.tipo,
        numero: p.numero,
        fechaInicio: String(p.fechaInicio).slice(0, 10),
        fechaFin: String(p.fechaFin).slice(0, 10),
        estado: p.estado
    }

    error.value = ''
    mensaje.value = ''

    mostrarFormulario.value = true
}

// CERRAR FORMULARIO
function cerrarFormulario() {

    mostrarFormulario.value = false
    limpiarFormulario()

}

// GUARDAR PERIODO
async function guardarPeriodo() {

    error.value = ''
    mensaje.value = ''

    if (
        new Date(formulario.value.fechaInicio) >
        new Date(formulario.value.fechaFin)
    ) {
        error.value = 'La fecha de inicio debe ser anterior a la fecha final.'
        return
    }

    guardando.value = true

    try {

        const datos = { ...formulario.value }

        if (editando.value) {

            const respuesta = await periodosService.actualizar(
                idEdicion.value,
                datos
            )

            mensaje.value = respuesta.mensaje

        } else {

            const respuesta = await periodosService.crear(datos)

            mensaje.value = respuesta.mensaje

        }

        mostrarFormulario.value = false
        limpiarFormulario()

        await cargarPeriodos()

    } catch (e) {

        error.value = e.message

    } finally {

        guardando.value = false

    }
}

// ELIMINAR PERIODO
async function confirmarEliminar(p) {

    const confirmar = window.confirm(
        `¿Estás segura de eliminar el periodo "${p.nombre}"?`
    )

    if (!confirmar) return

    error.value = ''
    mensaje.value = ''

    try {

        const respuesta = await periodosService.eliminar(p._id)

        mensaje.value = respuesta.mensaje

        await cargarPeriodos()

    } catch (e) {

        error.value = e.message

    }
}

onMounted(cargarPeriodos)
</script>

<style scoped>
.periodos-page {
    display: flex;
    flex-direction: column;
    gap: 26px;
    color: #35483c;
}

.periodos-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.periodos-etiqueta {
    display: block;
    color: #79917d;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1.5px;
    margin-bottom: 10px;
}

.periodos-header h1 {
    font-size: 29px;
    margin-bottom: 7px;
}

.periodos-header p,
.periodos-tabla-titulo p {
    color: #89958b;
    font-size: 14px;
}

.periodos-btn-principal {
    border: none;
    border-radius: 10px;
    padding: 13px 19px;
    background: #426b58;
    color: white;
    font-weight: 600;
    transition: .2s;
}

.periodos-btn-principal:hover {
    background: #315642;
}

.periodos-btn-principal:disabled {
    opacity: .6;
    cursor: not-allowed;
}

.periodos-estadisticas {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
}

.periodo-stat {
    background: white;
    border: 1px solid #e5ebe4;
    border-radius: 15px;
    padding: 23px;
    display: flex;
    flex-direction: column;
    gap: 11px;
}

.periodo-stat span {
    color: #89958b;
    font-size: 13px;
}

.periodo-stat strong {
    font-size: 29px;
    color: #426b58;
}

.periodo-stat small {
    color: #9ba69c;
}

.periodos-filtros {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

.periodos-filtros input {
    flex: 1;
    min-width: 180px;
}

.periodos-filtros input,
.periodos-filtros select,
.periodos-campo input,
.periodos-campo select {
    background: white;
    border: 1px solid #dfe6de;
    border-radius: 9px;
    padding: 12px 14px;
    color: #35483c;
    outline: none;
}

.periodos-filtros input:focus,
.periodos-filtros select:focus,
.periodos-campo input:focus,
.periodos-campo select:focus {
    border-color: #829c87;
}

.periodos-btn-secundario {
    background: white;
    border: 1px solid #a9b9aa;
    border-radius: 9px;
    color: #426b58;
    padding: 11px 17px;
    cursor: pointer;
}

.periodos-tabla-contenedor {
    background: white;
    border: 1px solid #e5ebe4;
    border-radius: 15px;
    overflow: hidden;
}

.periodos-tabla-titulo {
    padding: 23px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
}

.periodos-tabla-titulo h2 {
    font-size: 18px;
    margin-bottom: 6px;
}

.periodos-tabla-titulo > span {
    color: #79917d;
    font-size: 13px;
}

.periodos-tabla {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
}

.periodos-tabla th {
    background: #f7f9f6;
    color: #718477;
    font-size: 12px;
    font-weight: 600;
    padding: 16px;
    white-space: nowrap;
}

.periodos-tabla td {
    padding: 17px 16px;
    border-top: 1px solid #edf0ec;
    font-size: 13px;
}

.periodos-tabla td strong {
    color: #35483c;
}

.periodo-estado {
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.estado-activo {
    color: #28734b;
    background: #e5f2e9;
}

.estado-planeado {
    color: #96712e;
    background: #f8f0d9;
}

.estado-finalizado {
    color: #687b8d;
    background: #e9eef3;
}

.periodos-acciones {
    display: flex;
    gap: 7px;
}

.periodo-btn-editar,
.periodo-btn-eliminar {
    width: 34px;
    height: 34px;
    border-radius: 8px;
    background: white;
    border: 1px solid #dfe6de;
    cursor: pointer;
    font-size: 17px;
}

.periodo-btn-editar {
    color: #426b58;
}

.periodo-btn-eliminar {
    color: #bc6868;
}

.periodos-vacio {
    text-align: center;
    padding: 35px !important;
    color: #929d93;
}

.periodos-error,
.periodos-exito {
    padding: 13px 16px;
    border-radius: 9px;
    font-size: 13px;
}

.periodos-error {
    background: #fbeaea;
    color: #a94444;
}

.periodos-exito {
    background: #e6f2e9;
    color: #36724d;
}

.periodos-modal-fondo {
    position: fixed;
    inset: 0;
    z-index: 1000;
    background: rgba(30, 48, 39, .48);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.periodos-modal {
    width: 100%;
    max-width: 580px;
    max-height: 90vh;
    overflow-y: auto;
    background: white;
    border-radius: 17px;
    padding: 27px;
}

.periodos-modal-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 25px;
}

.periodos-modal-header h2 {
    margin-bottom: 8px;
}

.periodos-modal-header p {
    color: #89958b;
    font-size: 13px;
}

.periodos-cerrar {
    background: none;
    border: none;
    font-size: 27px;
    color: #829187;
    cursor: pointer;
}

.periodos-formulario {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 19px;
}

.periodos-campo {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.periodos-campo label {
    font-size: 13px;
    font-weight: 600;
}

.periodos-campo input,
.periodos-campo select {
    width: 100%;
}

.periodos-modal-acciones {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 27px;
}

@media (max-width: 950px) {
    .periodos-estadisticas {
        grid-template-columns: repeat(2, 1fr);
    }

    .periodos-tabla-contenedor {
        overflow-x: auto;
    }
}

@media (max-width: 600px) {
    .periodos-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .periodos-estadisticas {
        grid-template-columns: 1fr 1fr;
    }

    .periodos-formulario {
        grid-template-columns: 1fr;
    }

    .periodos-modal-acciones {
        flex-direction: column;
    }
}
</style>
