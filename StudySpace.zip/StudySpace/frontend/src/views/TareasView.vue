
<template>
    <div class="tareas-page">

        <!-- ENCABEZADO -->
        <section class="page-heading">
            <div>
                <span class="section-eyebrow">ORGANIZACIÓN ACADÉMICA</span>
                <h1>Mis tareas</h1>
                <p>Organiza tus actividades y mantén el control de tus entregas.</p>
            </div>

            <button class="new-task-btn" @click="abrirNueva()">
                + Nueva tarea
            </button>
        </section>

        <!-- RESUMEN -->
        <section class="task-stats">

            <div class="stat-card">
                <span>Total de tareas</span>
                <strong>{{ tareas.length }}</strong>
                <small>Actividades registradas</small>
            </div>

            <div class="stat-card">
                <span>Pendientes</span>
                <strong>{{ contar('Pendiente') }}</strong>
                <small>Por comenzar</small>
            </div>

            <div class="stat-card">
                <span>En progreso</span>
                <strong>{{ contar('En progreso') }}</strong>
                <small>En desarrollo</small>
            </div>

            <div class="stat-card">
                <span>Completadas</span>
                <strong>{{ contar('Completada') }}</strong>
                <small>Actividades terminadas</small>
            </div>

        </section>

        <!-- FILTROS -->
        <section class="task-filters">

            <input
                v-model="busqueda"
                type="search"
                placeholder="Buscar una tarea..."
            />

            <select v-model="filtroMateria">
                <option value="">Todas las materias</option>
                <option value="general">Tareas generales</option>

                <option
                    v-for="materia in materias"
                    :key="materia._id"
                    :value="materia._id"
                >
                    {{ materia.nombre }}
                </option>
            </select>

            <select v-model="filtroPrioridad">
                <option value="">Todas las prioridades</option>
                <option value="Alta">Prioridad alta</option>
                <option value="Media">Prioridad media</option>
                <option value="Baja">Prioridad baja</option>
            </select>

            <select v-model="filtroTipo">
                <option value="">Todos los tipos</option>
                <option v-for="tipo in tipos" :key="tipo">
                    {{ tipo }}
                </option>
            </select>


        </section>

        <!-- MENSAJES -->
        <div v-if="error" class="task-alert">
            {{ error }}
        </div>

        <div v-if="mensaje" class="task-success">
            {{ mensaje }}
        </div>

        <div v-if="cargando" class="loading-message">
            Cargando tareas...
        </div>

        <!-- TABLERO -->
        <section class="kanban-board">

            <div
                v-for="columna in columnas"
                :key="columna.estado"
                class="kanban-column"
                @dragover.prevent
                @drop="soltarTarea($event, columna.estado)"
            >

                <div class="column-header">

                    <div class="column-title">
                        <span :class="['column-dot', columna.color]"></span>
                        <h3>{{ columna.nombre }}</h3>
                    </div>

                    <span class="column-count">
                        {{ tareasPorEstado(columna.estado).length }}
                    </span>

                </div>

                <div class="column-description">
                    {{ columna.descripcion }}
                </div>

                <!-- TARJETAS -->
                <div class="task-list">

                    <article
                        v-for="tarea in tareasPorEstado(columna.estado)"
                        :key="tarea._id"
                        class="task-card"
                        draggable="true"
                        @dragstart="arrastrarTarea($event, tarea)"
                        @dragend="tareaArrastrada = null"
                    >

                        <div class="task-card-top">

                            <span :class="['priority-badge', clasePrioridad(tarea.prioridad)]">
                                {{ tarea.prioridad }}
                            </span>

                            <div class="task-actions">
                                <button
                                    title="Editar tarea"
                                    @click="editar(tarea)"
                                >
                                    ✎
                                </button>

                                <button
                                    title="Eliminar tarea"
                                    @click="eliminar(tarea)"
                                >
                                    ×
                                </button>
                            </div>

                        </div>

                        <h4>{{ tarea.titulo }}</h4>

                        <div class="task-category">
                            {{ tarea.tipo }}
                        </div>

                        <div class="task-subject">
                            <span
                                class="subject-dot"
                                :style="{
                                    background: tarea.materiaId?.color || '#A3B49A'
                                }"
                            ></span>

                            {{ tarea.materiaId?.nombre || 'General / Sin materia' }}
                        </div>

                        <div
                            v-if="tarea.fechaEntrega"
                            :class="['task-date', { overdue: estaVencida(tarea) }]"
                        >
                            ◷ {{ formatearFecha(tarea.fechaEntrega) }}
                            <span v-if="estaVencida(tarea)"> · Vencida</span>
                            <span v-else-if="tarea.horaEntrega">
                                · {{ tarea.horaEntrega }}
                            </span>
                        </div>

                        <div class="task-card-footer">

                            <span v-if="tarea.notas" class="notes-indicator">
                                ▤ Con notas
                            </span>

                            <select
                                :value="tarea.estado"
                                @change="actualizarEstado(tarea, $event.target.value)"
                            >
                                <option>Pendiente</option>
                                <option>En progreso</option>
                                <option>Completada</option>
                            </select>

                        </div>

                    </article>

                    <div
                        v-if="tareasPorEstado(columna.estado).length === 0"
                        class="empty-column"
                    >
                        <span>✧</span>
                        <p>No hay tareas aquí</p>
                    </div>

                </div>

                <button
                    class="add-column-task"
                    @click="abrirNueva(columna.estado)"
                >
                    + Agregar tarea
                </button>

            </div>

        </section>

        <!-- MODAL -->
        <TareaModal
            :mostrar="mostrarModal"
            :tarea="tareaSeleccionada"
            :materias="materias"
            :guardando="guardando"
            @cerrar="cerrarModal"
            @guardar="guardarTarea"
        />

    </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import TareaModal from '../components/TareaModal.vue'

import {
    obtenerTareas,
    crearTarea,
    actualizarTarea as editarTareaAPI,
    cambiarEstado as cambiarEstadoAPI,
    eliminarTarea as eliminarTareaAPI
} from '../services/tareaService'

const tareas = ref([])
const materias = ref([])

const cargando = ref(false)
const guardando = ref(false)

const error = ref('')
const mensaje = ref('')

const busqueda = ref('')
const filtroMateria = ref('')
const filtroPrioridad = ref('')
const filtroTipo = ref('')

const mostrarModal = ref(false)
const tareaSeleccionada = ref(null)
const tareaArrastrada = ref(null)

let temporizadorBusqueda

const tipos = [
    'Tarea',
    'Examen',
    'Exposición',
    'Proyecto',
    'Lectura',
    'Otro'
]

const columnas = [
    {
        nombre: 'Pendientes',
        estado: 'Pendiente',
        descripcion: 'Actividades por comenzar',
        color: 'dot-pending'
    },
    {
        nombre: 'En progreso',
        estado: 'En progreso',
        descripcion: 'Actividades en desarrollo',
        color: 'dot-progress'
    },
    {
        nombre: 'Completadas',
        estado: 'Completada',
        descripcion: 'Actividades terminadas',
        color: 'dot-completed'
    }
]

const filtros = computed(() => ({
    materiaId: filtroMateria.value,
    prioridad: filtroPrioridad.value,
    tipo: filtroTipo.value,
    busqueda: busqueda.value.trim()
}))

const contar = (estado) => {
    return tareas.value.filter(t => t.estado === estado).length
}

const tareasPorEstado = (estado) => {
    return tareas.value.filter(t => t.estado === estado)
}

const clasePrioridad = (prioridad) => {
    return {
        Alta: 'priority-high',
        Media: 'priority-medium',
        Baja: 'priority-low'
    }[prioridad] || ''
}

const formatearFecha = (fecha) => {
    const valor = String(fecha).slice(0, 10)
    const [anio, mes, dia] = valor.split('-')

    return `${dia}/${mes}/${anio}`
}

const estaVencida = (tarea) => {
    if (!tarea.fechaEntrega || tarea.estado === 'Completada') {
        return false
    }

    const hoy = new Date()
    const fechaHoy = new Date(
        hoy.getFullYear(),
        hoy.getMonth(),
        hoy.getDate()
    )

    const fecha = new Date(`${String(tarea.fechaEntrega).slice(0, 10)}T00:00:00`)

    return fecha < fechaHoy
}

const cargarTareas = async () => {
    cargando.value = true
    error.value = ''

    try {
        const respuesta = await obtenerTareas(filtros.value)
        tareas.value = respuesta.tareas

    } catch (err) {
        error.value = err.message || 'No fue posible cargar las tareas'

    } finally {
        cargando.value = false
    }
}

const cargarMaterias = async () => {
    try {
        const respuesta = await fetch('http://localhost:3000/api/materias')

        if (!respuesta.ok) {
            throw new Error('No se pudieron consultar las materias')
        }

        const datos = await respuesta.json()
        materias.value = datos.materias || []

    } catch (err) {
        error.value = err.message
    }
}

const abrirNueva = (estado = 'Pendiente') => {
    tareaSeleccionada.value = null

    // Evita que un evento de clic llegue a MongoDB como si fuera un estado.
    const estadosPermitidos = [
        'Pendiente',
        'En progreso',
        'Completada'
    ]

    estadoInicial.value = estadosPermitidos.includes(estado)
        ? estado
        : 'Pendiente'

    mostrarModal.value = true
}

const estadoInicial = ref('Pendiente')

const editar = (tarea) => {
    tareaSeleccionada.value = { ...tarea }
    mostrarModal.value = true
}

const cerrarModal = () => {
    mostrarModal.value = false
    tareaSeleccionada.value = null
    estadoInicial.value = 'Pendiente'
}

const guardarTarea = async (datos) => {
    guardando.value = true
    error.value = ''

    try {
        if (tareaSeleccionada.value) {
            await editarTareaAPI(tareaSeleccionada.value._id, datos)
            mensaje.value = 'Tarea actualizada correctamente.'
        } else {
            datos.estado = estadoInicial.value
            await crearTarea(datos)
            mensaje.value = 'Tarea creada correctamente.'
        }

        cerrarModal()
        await cargarTareas()

    } catch (err) {
        error.value = err.message

    } finally {
        guardando.value = false
    }
}

const actualizarEstado = async (tarea, estado) => {
    const estadoAnterior = tarea.estado

    tarea.estado = estado

    try {
        await cambiarEstadoAPI(tarea._id, estado)
        mensaje.value = 'Estado actualizado correctamente.'
        await cargarTareas()

    } catch (err) {
        tarea.estado = estadoAnterior
        error.value = err.message
    }
}

const arrastrarTarea = (evento, tarea) => {
    tareaArrastrada.value = tarea
    evento.dataTransfer.effectAllowed = 'move'
    evento.dataTransfer.setData('text/plain', tarea._id)
}

const soltarTarea = async (evento, estado) => {
    evento.preventDefault()

    const id = evento.dataTransfer.getData('text/plain')
    const tarea = tareas.value.find(t => t._id === id)

    if (tarea && tarea.estado !== estado) {
        await actualizarEstado(tarea, estado)
    }

    tareaArrastrada.value = null
}

const eliminar = async (tarea) => {
    const confirmar = window.confirm(
        `¿Deseas eliminar la tarea "${tarea.titulo}"?`
    )

    if (!confirmar) return

    try {
        await eliminarTareaAPI(tarea._id)
        mensaje.value = 'Tarea eliminada correctamente.'
        await cargarTareas()

    } catch (err) {
        error.value = err.message
    }
}

onMounted(async () => {
    await cargarMaterias()
    await cargarTareas()
})

// Actualizar la búsqueda sin hacer una petición por cada tecla
watch(
    [busqueda, filtroMateria, filtroPrioridad, filtroTipo],
    () => {
        clearTimeout(temporizadorBusqueda)

        temporizadorBusqueda = setTimeout(() => {
            cargarTareas()
        }, 300)
    }
)
</script>

<style scoped>
.tareas-page {
    padding: 35px 40px;
    color: #29483d;
}

.page-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 30px;
}

.section-eyebrow {
    color: #78917c;
    font-size: 12px;
    letter-spacing: 1.5px;
    font-weight: 700;
}

.page-heading h1 {
    font-size: 30px;
    margin: 10px 0;
    color: #244438;
}

.page-heading p {
    color: #87978e;
    margin: 0;
}

.new-task-btn {
    background: #426b59;
    color: white;
    border: none;
    border-radius: 10px;
    padding: 15px 22px;
    font-weight: 600;
    cursor: pointer;
}

.task-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border: 1px solid #e3eae3;
    border-radius: 16px;
    padding: 23px;
}

.stat-card span,
.stat-card small {
    display: block;
    color: #87978e;
}

.stat-card strong {
    display: block;
    font-size: 30px;
    color: #38664f;
    margin: 12px 0;
}

.stat-card small {
    font-size: 12px;
}

.task-filters {
    display: grid;
    grid-template-columns: minmax(180px, 1fr) repeat(3, minmax(135px, auto)) auto;
    gap: 12px;
    margin-bottom: 25px;
}

.task-filters input,
.task-filters select {
    min-width: 0;
    padding: 13px;
    background: white;
    border: 1px solid #dce5dc;
    border-radius: 9px;
    color: #456356;
    font: inherit;
}

.refresh-btn {
    border: 1px solid #b9cbbb;
    background: white;
    color: #426b59;
    border-radius: 9px;
    padding: 12px 17px;
    cursor: pointer;
}

.kanban-board {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 18px;
    align-items: start;
}

.kanban-column {
    background: #edf1ec;
    border: 1px solid #e1e8e0;
    border-radius: 14px;
    padding: 17px;
    min-height: 390px;
}

.column-header,
.column-title {
    display: flex;
    align-items: center;
}

.column-header {
    justify-content: space-between;
}

.column-title {
    gap: 10px;
}

.column-title h3 {
    margin: 0;
    font-size: 16px;
    color: #315344;
}

.column-dot,
.subject-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
}

.dot-pending { background: #c69a59; }
.dot-progress { background: #7095ad; }
.dot-completed { background: #76a889; }

.column-count {
    background: white;
    border-radius: 20px;
    padding: 5px 10px;
    color: #648171;
    font-size: 12px;
}

.column-description {
    font-size: 12px;
    color: #92a097;
    margin: 9px 0 18px;
}

.task-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-height: 230px;
}

.task-card {
    background: white;
    border: 1px solid #e0e8df;
    border-radius: 12px;
    padding: 16px;
    cursor: grab;
    transition: transform .2s, box-shadow .2s;
}

.task-card:active {
    cursor: grabbing;
}

.task-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(39, 75, 57, .08);
}

.task-card-top,
.task-card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
}

.priority-badge {
    font-size: 11px;
    border-radius: 20px;
    padding: 5px 9px;
}

.priority-high {
    background: #fbe9e6;
    color: #bd6959;
}

.priority-medium {
    background: #f7f0dc;
    color: #a5833e;
}

.priority-low {
    background: #e8f1e8;
    color: #64876a;
}

.task-actions {
    display: flex;
    gap: 5px;
}

.task-actions button {
    border: 0;
    background: transparent;
    color: #759082;
    font-size: 17px;
    cursor: pointer;
}

.task-card h4 {
    margin: 15px 0 8px;
    color: #29483d;
    font-size: 15px;
}

.task-category {
    display: inline-block;
    background: #eff3ed;
    color: #698273;
    padding: 5px 8px;
    font-size: 11px;
    border-radius: 6px;
}

.task-subject {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #778b7e;
    font-size: 12px;
    margin-top: 15px;
}

.task-date {
    margin-top: 13px;
    font-size: 12px;
    color: #819186;
}

.task-date.overdue {
    color: #bf625b;
    font-weight: 600;
}

.task-card-footer {
    margin-top: 15px;
    padding-top: 12px;
    border-top: 1px solid #eef1ed;
}

.task-card-footer select {
    border: 1px solid #e0e8df;
    border-radius: 6px;
    padding: 5px;
    max-width: 135px;
    color: #587364;
    background: white;
    font-size: 11px;
}

.notes-indicator {
    color: #8b9b90;
    font-size: 11px;
}

.empty-column {
    text-align: center;
    color: #9aa89f;
    padding: 45px 10px;
}

.empty-column span {
    font-size: 25px;
}

.empty-column p {
    font-size: 12px;
}

.add-column-task {
    width: 100%;
    margin-top: 15px;
    padding: 11px;
    border: 1px dashed #b9cabb;
    border-radius: 9px;
    color: #648171;
    background: transparent;
    cursor: pointer;
}

.add-column-task:hover {
    background: white;
}

.task-alert,
.task-success,
.loading-message {
    padding: 15px;
    margin-bottom: 18px;
    border-radius: 9px;
}

.task-alert {
    background: #fbe9e9;
    color: #b65b5b;
}

.task-success {
    background: #e6f2e9;
    color: #43805c;
}

.loading-message {
    color: #688171;
}

@media (max-width: 1100px) {
    .task-filters {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .kanban-board {
        grid-template-columns: 1fr;
    }

    .task-stats {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 600px) {
    .tareas-page {
        padding: 20px 15px;
    }

    .page-heading {
        align-items: flex-start;
        flex-direction: column;
    }

    .task-filters,
    .task-stats {
        grid-template-columns: 1fr;
    }
}
</style>
