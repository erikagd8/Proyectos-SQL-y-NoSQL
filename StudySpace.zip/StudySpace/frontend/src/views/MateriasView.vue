
<template>
    <div class="materias-page">

        <!-- ENCABEZADO -->
        <header class="page-header">
            <div>
                <span class="eyebrow">ORGANIZACIÓN ACADÉMICA</span>
                <h1>Mis materias</h1>
                <p>Administra tus asignaturas y organiza tu vida universitaria.</p>
            </div>

            <button class="btn-primary" @click="abrirFormulario()">
                + Nueva materia
            </button>
        </header>

        <!-- ESTADÍSTICAS -->
        <section class="stats-grid">
            <article class="stat-card">
                <span>Total de materias</span>
                <strong>{{ materias.length }}</strong>
                <small>Asignaturas registradas</small>
            </article>

            <article class="stat-card">
                <span>Materias activas</span>
                <strong>{{ activas }}</strong>
                <small>En curso</small>
            </article>

            <article class="stat-card">
                <span>Finalizadas</span>
                <strong>{{ finalizadas }}</strong>
                <small>Asignaturas concluidas</small>
            </article>
        </section>

        <!-- MENSAJES -->
        <div v-if="mensaje" class="alert success">
            {{ mensaje }}
        </div>

        <div v-if="error" class="alert danger">
            {{ error }}
        </div>

        <!-- FILTROS -->
        <section class="filters">
            <input
                v-model="busqueda"
                type="search"
                placeholder="Buscar materia o docente..."
            >

            <select v-model="filtroPeriodo">
                <option value="">Todos los periodos</option>
                <option
                    v-for="periodo in periodos"
                    :key="periodo._id"
                    :value="periodo._id"
                >
                    {{ periodo.nombre }} - {{ periodo.tipo }}
                </option>
            </select>

            <select v-model="filtroEstado">
                <option value="">Todos los estados</option>
                <option value="Activa">Activas</option>
                <option value="Finalizada">Finalizadas</option>
            </select>

        
        </section>

        <!-- TABLA -->
        <section class="table-card">

            <div class="table-header">
                <div>
                    <h2>Mi catálogo académico</h2>
                    <p>Consulta y administra tus asignaturas.</p>
                </div>

                <span>{{ materiasFiltradas.length }} registros</span>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Materia</th>
                            <th>Docente</th>
                            <th>Periodo académico</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr
                            v-for="materia in materiasFiltradas"
                            :key="materia._id"
                        >
                            <td>
                                <div class="materia-name">
                                    <span
                                        class="color-dot"
                                        :style="{ background: materia.color }"
                                    ></span>

                                    <strong>{{ materia.nombre }}</strong>
                                </div>
                            </td>

                            <td>
                                {{ materia.docente || 'Sin asignar' }}
                            </td>

                            <td>
                                <div v-if="materia.periodo">
                                    <strong>{{ materia.periodo.nombre }}</strong>
                                    <small>
                                        {{ materia.periodo.tipo }}
                                        {{ materia.periodo.numero }}
                                    </small>
                                </div>

                                <span v-else>Sin periodo</span>
                            </td>

                            <td>
                                <span
                                    class="status"
                                    :class="materia.estado === 'Activa'
                                        ? 'status-active'
                                        : 'status-finished'"
                                >
                                    {{ materia.estado }}
                                </span>
                            </td>

                            <!-- ACCIONES -->
                            <td>
                                <div class="actions">

                                    <button
                                        class="action-btn"
                                        title="Editar materia"
                                        @click="abrirFormulario(materia)"
                                    >
                                        ✎
                                    </button>

                                    <button
                                        class="action-btn"
                                        :title="materia.estado === 'Activa'
                                            ? 'Finalizar materia'
                                            : 'Reactivar materia'"
                                        @click="alternarEstado(materia)"
                                    >
                                        {{ materia.estado === 'Activa' ? '✓' : '↻' }}
                                    </button>

                                    <button
                                        class="action-btn delete-btn"
                                        title="Eliminar materia"
                                        :disabled="eliminandoId === materia._id"
                                        @click="eliminarMateriaUI(materia)"
                                    >
                                        {{ eliminandoId === materia._id ? '...' : '×' }}
                                    </button>

                                </div>
                            </td>
                        </tr>

                        <tr v-if="materiasFiltradas.length === 0">
                            <td colspan="5" class="empty-state">
                                <span>▤</span>
                                <strong>No se encontraron materias.</strong>
                                <small>
                                    Registra una nueva asignatura o modifica los filtros.
                                </small>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- MODAL DE REGISTRO Y EDICIÓN -->
        <div
            v-if="mostrarFormulario"
            class="modal-overlay"
            @click.self="cerrarFormulario"
        >
            <div class="modal-card">

                <div class="modal-header">
                    <div>
                        <span class="eyebrow">ORGANIZACIÓN ACADÉMICA</span>

                        <h2>
                            {{ editando ? 'Editar materia' : 'Nueva materia' }}
                        </h2>

                        <p>Completa la información de tu asignatura.</p>
                    </div>

                    <button
                        class="close-btn"
                        type="button"
                        @click="cerrarFormulario"
                    >
                        ×
                    </button>
                </div>

                <form @submit.prevent="guardarMateria">
                    <div class="form-grid">

                        <div class="form-group full">
                            <label>Nombre de la materia *</label>
                            <input
                                v-model.trim="formulario.nombre"
                                type="text"
                                placeholder="Ej. Cardiología"
                                required
                            >
                        </div>

                        <div class="form-group full">
                            <label>Docente</label>
                            <input
                                v-model.trim="formulario.docente"
                                type="text"
                                placeholder="Nombre del profesor"
                            >
                        </div>

                        <div class="form-group full">
                            <label>Periodo académico *</label>

                            <select
                                v-model="formulario.periodo"
                                required
                            >
                                <option value="" disabled>
                                    Selecciona un periodo
                                </option>

                                <option
                                    v-for="periodo in periodosDisponibles"
                                    :key="periodo._id"
                                    :value="periodo._id"
                                >
                                    {{ periodo.nombre }} -
                                    {{ periodo.tipo }}
                                    {{ periodo.numero }}
                                </option>
                            </select>

                            <small v-if="periodosDisponibles.length === 0">
                                Primero registra un periodo académico activo o planeado.
                            </small>
                        </div>

                        <div class="form-group full">
                            <label>Color identificador</label>

                            <div class="color-selector">
                                <input
                                    v-model="formulario.color"
                                    type="color"
                                >
                                <span>{{ formulario.color }}</span>
                            </div>
                        </div>

                    </div>

                    <div class="modal-actions">
                        <button
                            type="button"
                            class="btn-secondary"
                            @click="cerrarFormulario"
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            class="btn-primary"
                            :disabled="guardando || periodosDisponibles.length === 0"
                        >
                            {{
                                guardando
                                    ? 'Guardando...'
                                    : editando
                                        ? 'Guardar cambios'
                                        : 'Registrar materia'
                            }}
                        </button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

import {
    obtenerMaterias,
    obtenerPeriodos,
    crearMateria,
    actualizarMateria,
    cambiarEstadoMateria,
    eliminarMateria as eliminarMateriaAPI
} from '../services/materiaService'

// DATOS
const materias = ref([])
const periodos = ref([])

// FILTROS
const busqueda = ref('')
const filtroPeriodo = ref('')
const filtroEstado = ref('')

// FORMULARIO
const mostrarFormulario = ref(false)
const editando = ref(false)
const guardando = ref(false)
const idMateria = ref(null)

// ELIMINACIÓN
const eliminandoId = ref(null)

// MENSAJES
const mensaje = ref('')
const error = ref('')

// DATOS DEL FORMULARIO
const formulario = ref({
    nombre: '',
    docente: '',
    color: '#78917C',
    periodo: ''
})

// ESTADÍSTICAS
const activas = computed(() => {
    return materias.value.filter(
        materia => materia.estado === 'Activa'
    ).length
})

const finalizadas = computed(() => {
    return materias.value.filter(
        materia => materia.estado === 'Finalizada'
    ).length
})

// PERIODOS DISPONIBLES
const periodosDisponibles = computed(() => {
    return periodos.value.filter(
        periodo => periodo.estado !== 'Finalizado'
    )
})

// MATERIAS FILTRADAS
const materiasFiltradas = computed(() => {
    return materias.value.filter(materia => {

        const texto = busqueda.value.toLowerCase()

        const nombre = (materia.nombre || '').toLowerCase()
        const docente = (materia.docente || '').toLowerCase()

        const coincideBusqueda =
            nombre.includes(texto) ||
            docente.includes(texto)

        const coincidePeriodo =
            !filtroPeriodo.value ||
            materia.periodo?._id === filtroPeriodo.value

        const coincideEstado =
            !filtroEstado.value ||
            materia.estado === filtroEstado.value

        return coincideBusqueda &&
            coincidePeriodo &&
            coincideEstado
    })
})

// CARGAR DATOS
async function cargarDatos() {
    error.value = ''

    try {
        const [respuestaMaterias, respuestaPeriodos] =
            await Promise.all([
                obtenerMaterias(),
                obtenerPeriodos()
            ])

        materias.value = respuestaMaterias.materias || []
        periodos.value = respuestaPeriodos.periodos || []

    } catch (e) {
        error.value = e.message
    }
}

// LIMPIAR FORMULARIO
function limpiarFormulario() {
    formulario.value = {
        nombre: '',
        docente: '',
        color: '#78917C',
        periodo: ''
    }

    idMateria.value = null
    editando.value = false
}

// ABRIR FORMULARIO
function abrirFormulario(materia = null) {
    limpiarFormulario()

    mensaje.value = ''
    error.value = ''

    if (materia) {
        editando.value = true
        idMateria.value = materia._id

        formulario.value = {
            nombre: materia.nombre,
            docente: materia.docente || '',
            color: materia.color || '#78917C',
            periodo: materia.periodo?._id || ''
        }
    }

    mostrarFormulario.value = true
}

// CERRAR FORMULARIO
function cerrarFormulario() {
    mostrarFormulario.value = false
    limpiarFormulario()
}

// GUARDAR MATERIA
async function guardarMateria() {
    if (!formulario.value.nombre.trim()) {
        error.value = 'Escribe el nombre de la materia.'
        return
    }

    if (!formulario.value.periodo) {
        error.value = 'Selecciona un periodo académico.'
        return
    }

    guardando.value = true
    error.value = ''
    mensaje.value = ''

    try {
        if (editando.value) {
            await actualizarMateria(
                idMateria.value,
                formulario.value
            )

            mensaje.value = 'Materia actualizada correctamente.'
        } else {
            await crearMateria(formulario.value)

            mensaje.value = 'Materia registrada correctamente.'
        }

        cerrarFormulario()
        await cargarDatos()

    } catch (e) {
        error.value = e.message
    } finally {
        guardando.value = false
    }
}

// FINALIZAR O REACTIVAR MATERIA
async function alternarEstado(materia) {
    const nuevoEstado =
        materia.estado === 'Activa'
            ? 'Finalizada'
            : 'Activa'

    const confirmacion = window.confirm(
        `¿Deseas cambiar el estado de "${materia.nombre}" a ${nuevoEstado}?`
    )

    if (!confirmacion) return

    error.value = ''
    mensaje.value = ''

    try {
        await cambiarEstadoMateria(
            materia._id,
            nuevoEstado
        )

        mensaje.value =
            `Materia ${nuevoEstado.toLowerCase()} correctamente.`

        await cargarDatos()

    } catch (e) {
        error.value = e.message
    }
}

// ELIMINAR MATERIA
async function eliminarMateriaUI(materia) {
    const confirmar = window.confirm(
        `¿Estás seguro de eliminar la materia "${materia.nombre}"?\n\n` +
        'Las tareas relacionadas se conservarán, pero pasarán a ser actividades generales.'
    )

    if (!confirmar) return

    eliminandoId.value = materia._id
    error.value = ''
    mensaje.value = ''

    try {
        const respuesta = await eliminarMateriaAPI(materia._id)

        mensaje.value =
            respuesta.mensaje || 'Materia eliminada correctamente.'

        await cargarDatos()

    } catch (e) {
        error.value = e.message
    } finally {
        eliminandoId.value = null
    }
}

// INICIALIZAR
onMounted(cargarDatos)
</script>

<style scoped>
.materias-page {
    width: 100%;
    color: #263e35;
}

/* ENCABEZADO */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 28px;
}

.eyebrow {
    display: block;
    color: #78917c;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 1.4px;
    margin-bottom: 12px;
}

.page-header h1 {
    font-size: 30px;
    margin: 0 0 8px;
}

.page-header p,
.table-header p,
.modal-header p {
    color: #82918a;
    margin: 0;
}

/* BOTONES */
.btn-primary,
.btn-secondary {
    border-radius: 10px;
    padding: 13px 20px;
    cursor: pointer;
    font-size: 14px;
    transition: 0.2s;
}

.btn-primary {
    background: #416b59;
    border: 1px solid #416b59;
    color: white;
    font-weight: 600;
}

.btn-primary:hover {
    background: #315747;
}

.btn-primary:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.btn-secondary {
    background: white;
    border: 1px solid #cbd7ce;
    color: #416b59;
}

/* ESTADÍSTICAS */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border: 1px solid #e4ebe5;
    border-radius: 17px;
    padding: 25px;
}

.stat-card span,
.stat-card small {
    display: block;
    color: #82918a;
}

.stat-card strong {
    display: block;
    color: #416b59;
    font-size: 30px;
    margin: 12px 0;
}

.stat-card small {
    font-size: 12px;
}

/* FILTROS */
.filters {
    display: grid;
    grid-template-columns: 1fr 220px 180px auto;
    gap: 12px;
    margin-bottom: 25px;
}

.filters input,
.filters select,
.form-group input,
.form-group select {
    width: 100%;
    padding: 13px 14px;
    border: 1px solid #dce5de;
    border-radius: 9px;
    background: white;
    color: #344b40;
    font: inherit;
    box-sizing: border-box;
}

.filters input:focus,
.filters select:focus,
.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: #78917c;
    box-shadow: 0 0 0 3px #78917c18;
}

/* TABLA */
.table-card {
    background: white;
    border: 1px solid #e4ebe5;
    border-radius: 17px;
    overflow: hidden;
}

.table-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 25px;
}

.table-header h2 {
    font-size: 19px;
    margin: 0 0 7px;
}

.table-header > span {
    color: #82918a;
    font-size: 13px;
}

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 700px;
}

th {
    background: #f6f8f6;
    color: #65796d;
    font-size: 13px;
    font-weight: 600;
    text-align: left;
    padding: 17px;
}

td {
    padding: 17px;
    border-top: 1px solid #edf0ed;
    font-size: 13px;
}

.materia-name {
    display: flex;
    align-items: center;
    gap: 12px;
}

.color-dot {
    width: 11px;
    height: 35px;
    border-radius: 6px;
    flex-shrink: 0;
}

td small {
    display: block;
    color: #8a9990;
    margin-top: 5px;
}

/* ESTADOS */
.status {
    display: inline-block;
    border-radius: 20px;
    padding: 6px 12px;
    font-size: 11px;
    font-weight: 600;
}

.status-active {
    color: #25845c;
    background: #e5f3e9;
}

.status-finished {
    color: #8b7350;
    background: #f5eee1;
}

/* ACCIONES */
.actions {
    display: flex;
    gap: 8px;
}

.action-btn,
.close-btn {
    width: 38px;
    height: 38px;
    background: white;
    border: 1px solid #dce5de;
    border-radius: 9px;
    color: #416b59;
    cursor: pointer;
    font-size: 18px;
}

.action-btn:hover {
    background: #edf3ee;
}

.action-btn:disabled {
    opacity: 0.5;
    cursor: wait;
}

.delete-btn {
    color: #bc6868;
}

.delete-btn:hover {
    background: #fcebea;
    border-color: #e9c4c4;
}

/* ESTADO VACÍO */
.empty-state {
    text-align: center;
    padding: 50px 15px;
    color: #82918a;
}

.empty-state span,
.empty-state strong,
.empty-state small {
    display: block;
    margin-bottom: 10px;
}

.empty-state span {
    font-size: 30px;
}

/* ALERTAS */
.alert {
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 14px;
}

.success {
    background: #e6f3e9;
    color: #24744d;
}

.danger {
    background: #fcebea;
    color: #b33e3e;
}

/* MODAL */
.modal-overlay {
    position: fixed;
    inset: 0;
    background: #14251fcc;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    z-index: 1000;
    overflow-y: auto;
}

.modal-card {
    background: white;
    border-radius: 18px;
    padding: 28px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    box-sizing: border-box;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 25px;
}

.modal-header h2 {
    margin: 0 0 8px;
}

.close-btn {
    font-size: 25px;
    border: none;
    background: #f3f6f3;
}

/* FORMULARIO */
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.form-group label {
    font-size: 13px;
    font-weight: 600;
}

.form-group small {
    color: #9a7950;
    font-size: 12px;
}

.full {
    grid-column: 1 / -1;
}

.color-selector {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #82918a;
    font-size: 13px;
}

.color-selector input {
    width: 55px;
    height: 38px;
    padding: 3px;
    cursor: pointer;
}

/* ACCIONES DEL MODAL */
.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 28px;
}

/* RESPONSIVE */
@media (max-width: 900px) {
    .filters {
        grid-template-columns: 1fr 1fr;
    }

    .stats-grid {
        grid-template-columns: 1fr 1fr;
    }
}

@media (max-width: 600px) {
    .page-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .stats-grid {
        grid-template-columns: 1fr;
    }

    .filters {
        grid-template-columns: 1fr;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .full {
        grid-column: auto;
    }

    .modal-card {
        padding: 20px;
    }
}
</style>
