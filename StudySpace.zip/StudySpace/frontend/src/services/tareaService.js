const API_URL = 'http://localhost:3000/api/tareas'
const manejarRespuesta = async (respuesta) => {
    const datos = await respuesta.json()

    if (!respuesta.ok || datos.success === false) {
        console.error('Error de API:', datos)

        throw new Error(
            datos.error || datos.mensaje || 'Error de conexión'
        )
    }

    return datos
}
export const obtenerTareas = async (filtros = {}) => {
    const parametros = new URLSearchParams()

    Object.entries(filtros).forEach(([clave, valor]) => {
        if (valor !== '' && valor !== null && valor !== undefined) {
            parametros.append(clave, valor)
        }
    })
    const respuesta = await fetch(
        `${API_URL}?${parametros.toString()}`
    )

    return manejarRespuesta(respuesta)
}
export const crearTarea = async (datos) => {
    const respuesta = await fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    })
    return manejarRespuesta(respuesta)
}
export const actualizarTarea = async (id, datos) => {
    const respuesta = await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    })
    return manejarRespuesta(respuesta)
}
export const cambiarEstado = async (id, estado) => {
    const respuesta = await fetch(`${API_URL}/${id}/estado`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ estado })
    })

    return manejarRespuesta(respuesta)
}

export const eliminarTarea = async (id) => {
    const respuesta = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE'
    })

    return manejarRespuesta(respuesta)
}
