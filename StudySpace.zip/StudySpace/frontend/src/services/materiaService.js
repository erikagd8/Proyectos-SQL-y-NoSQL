const API = 'http://localhost:3000/api'
async function solicitar(url, opciones = {}) {
    const respuesta = await fetch(`${API}${url}`, {
        ...opciones,
        headers: {
            'Content-Type': 'application/json',
            ...opciones.headers
        }
    })

    const datos = await respuesta.json()

    if (!respuesta.ok || !datos.success) {
        throw new Error(datos.error || 'Error al comunicarse con el servidor')
    }

    return datos
}

// Obtener materias
export const obtenerMaterias = (filtros = {}) => {
    const parametros = new URLSearchParams()

    if (filtros.periodo) {
        parametros.append('periodo', filtros.periodo)
    }

    if (filtros.estado) {
        parametros.append('estado', filtros.estado)
    }

    const consulta = parametros.toString()

    return solicitar(`/materias${consulta ? `?${consulta}` : ''}`)
}

// Obtener periodos
export const obtenerPeriodos = () => {
    return solicitar('/periodos')
}

// Crear materia
export const crearMateria = (materia) => {
    return solicitar('/materias', {
        method: 'POST',
        body: JSON.stringify(materia)
    })
}

// Actualizar materia
export const actualizarMateria = (id, materia) => {
    return solicitar(`/materias/${id}`, {
        method: 'PUT',
        body: JSON.stringify(materia)
    })
}

// Cambiar estado
export const cambiarEstadoMateria = (id, estado) => {
    return solicitar(`/materias/${id}/estado`, {
        method: 'PATCH',
        body: JSON.stringify({ estado })
    })
}

// Eliminar materia
export const eliminarMateria = (id) => {
    return solicitar(`/materias/${id}`, {
        method: 'DELETE'
    })
}
