
const API = 'http://localhost:3000/api/periodos'

async function solicitar(url, opciones = {}) {
    const respuesta = await fetch(url, {
        ...opciones,
        headers: {
            'Content-Type': 'application/json',
            ...opciones.headers
        }
    })

    const datos = await respuesta.json()

    if (!respuesta.ok) {
        throw new Error(datos.error || 'Error en la solicitud.')
    }

    return datos
}

export const periodosService = {

    async obtenerTodos() {
        return solicitar(API)
    },

    async obtenerUno(id) {
        return solicitar(`${API}/${id}`)
    },

    async crear(datos) {
        return solicitar(API, {
            method: 'POST',
            body: JSON.stringify(datos)
        })
    },

    async actualizar(id, datos) {
        return solicitar(`${API}/${id}`, {
            method: 'PUT',
            body: JSON.stringify(datos)
        })
    },

    async eliminar(id) {
        return solicitar(`${API}/${id}`, {
            method: 'DELETE'
        })
    }

}
