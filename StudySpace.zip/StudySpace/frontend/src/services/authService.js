const API = 'http://localhost:3000/api/auth'

async function solicitar(url, opciones = {}) {

    const respuesta = await fetch(url, {
        ...opciones,
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json',
            ...opciones.headers
        }
    })

    const datos = await respuesta.json()

    if (!respuesta.ok || !datos.success) {
        throw new Error(
            datos.error || 'Error al comunicarse con el servidor.'
        )
    }

    return datos
}

export const authService = {

    // REGISTRAR CUENTA
    registrar(datos) {
        return solicitar(`${API}/registro`, {
            method: 'POST',
            body: JSON.stringify(datos)
        })
    },

    // INICIAR SESIÓN
    iniciarSesion(datos) {
        return solicitar(`${API}/login`, {
            method: 'POST',
            body: JSON.stringify(datos)
        })
    },

    // CERRAR SESIÓN
    cerrarSesion() {
        return solicitar(`${API}/logout`, {
            method: 'POST'
        })
    },

    // CONSULTAR SESIÓN
    obtenerSesion() {
        return solicitar(`${API}/me`)
    }

}