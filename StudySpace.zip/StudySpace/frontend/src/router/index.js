
import { createRouter, createWebHistory } from 'vue-router'

// Vistas
import DashboardView from '../views/DashboardView.vue'
import PeriodosView from '../views/PeriodosView.vue'
import MateriasView from '../views/MateriasView.vue'
import TareasView from '../views/TareasView.vue'
import LoginView from '../views/LoginView.vue'
import RegistroView from '../views/RegistroView.vue'
import { authService } from '../services/authService'

const routes = [
    {
    path: '/login',
    name: 'login',
    component: LoginView,
    meta: { publica: true }
},

{
    path: '/registro',
    name: 'registro',
    component: RegistroView,
    meta: { publica: true }
},

    {
        path: '/',
        name: 'inicio',
        component: DashboardView
    },

    {
        path: '/periodos',
        name: 'periodos',
        component: PeriodosView
    },

    {
        path: '/materias',
        name: 'materias',
        component: MateriasView
    },

    {
        path: '/tareas',
        name: 'tareas',
        component: TareasView
    },
    {
        path: '/:pathMatch(.*)*',
        redirect: '/'
    }

]

const router = createRouter({
    history: createWebHistory(),
    routes
})

router.beforeEach(async (to) => {

    if (to.meta.publica) {
        return true
    }

    try {
        await authService.obtenerSesion()
        return true

    } catch (error) {
        return { name: 'login' }
    }

})


export default router
