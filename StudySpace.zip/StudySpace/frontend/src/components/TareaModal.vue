
<template>
    <div v-if="mostrar" class="modal-overlay" @click.self="cerrar">
        <div class="tarea-modal">

            <!-- ENCABEZADO -->
            <div class="modal-header">
                <div>
                    <span class="modal-eyebrow">STUDYSPACE / ORGANIZACIÓN</span>
                    <h2>{{ editando ? 'Editar tarea' : 'Nueva tarea' }}</h2>
                    <p>Organiza tus actividades académicas.</p>
                </div>

                <button
                    type="button"
                    class="modal-close"
                    @click="cerrar"
                >
                    ×
                </button>
            </div>

            <!-- FORMULARIO -->
            <form @submit.prevent="guardar">

                <div class="form-group">
                    <label>Nombre de la actividad *</label>

                    <input
                        v-model.trim="form.titulo"
                        type="text"
                        placeholder="Ej. Investigar bases de datos"
                        maxlength="120"
                        required
                    />
                </div>

                <div class="form-row">

                    <div class="form-group">
                        <label>Tipo de actividad</label>

                        <select v-model="form.tipo">
                            <option
                                v-for="tipo in tipos"
                                :key="tipo"
                                :value="tipo"
                            >
                                {{ tipo }}
                            </option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Materia</label>

                        <select v-model="form.materiaId">
                            <option value="">
                                General / Sin materia
                            </option>

                            <option
                                v-for="materia in materias"
                                :key="materia._id"
                                :value="materia._id"
                            >
                                {{ materia.nombre }}
                            </option>
                        </select>
                    </div>

                </div>

                <div class="form-row">

                    <div class="form-group">
                        <label>Fecha de entrega</label>

                        <input
                            v-model="form.fechaEntrega"
                            type="date"
                        />
                    </div>

                    <div class="form-group">
                        <label>Hora de entrega</label>

                        <input
                            v-model="form.horaEntrega"
                            type="time"
                        />
                    </div>

                </div>

                <div class="form-row">

                    <div class="form-group">
                        <label>Prioridad</label>

                        <select v-model="form.prioridad">
                            <option value="Baja">Baja</option>
                            <option value="Media">Media</option>
                            <option value="Alta">Alta</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Estado</label>

                        <select v-model="form.estado">
                            <option value="Pendiente">Pendiente</option>
                            <option value="En progreso">En progreso</option>
                            <option value="Completada">Completada</option>
                        </select>
                    </div>

                </div>

                <div class="form-group">
                    <label>Notas adicionales</label>

                    <textarea
                        v-model="form.notas"
                        placeholder="Agrega indicaciones, detalles o recordatorios..."
                        rows="4"
                        maxlength="1000"
                    ></textarea>
                </div>

                <!-- BOTONES -->
                <div class="modal-actions">

                    <button
                        type="button"
                        class="btn-secondary"
                        @click="cerrar"
                    >
                        Cancelar
                    </button>

                    <button
                        type="submit"
                        class="btn-primary"
                        :disabled="guardando || !form.titulo.trim()"
                    >
                        {{
                            guardando
                                ? 'Guardando...'
                                : editando
                                    ? 'Guardar cambios'
                                    : 'Crear tarea'
                        }}
                    </button>

                </div>

            </form>
        </div>
    </div>
</template>

<script setup>
import { reactive, watch, computed } from 'vue'

const props = defineProps({
    mostrar: {
        type: Boolean,
        default: false
    },

    tarea: {
        type: Object,
        default: null
    },

    materias: {
        type: Array,
        default: () => []
    },

    guardando: {
        type: Boolean,
        default: false
    }
})

const emit = defineEmits([
    'cerrar',
    'guardar'
])

// TIPOS DE ACTIVIDADES
const tipos = [
    'Tarea',
    'Examen',
    'Exposición',
    'Proyecto',
    'Lectura',
    'Otro'
]

// FORMULARIO INICIAL
const formularioInicial = () => ({
    titulo: '',
    materiaId: '',
    tipo: 'Tarea',
    fechaEntrega: '',
    horaEntrega: '',
    prioridad: 'Media',
    estado: 'Pendiente',
    notas: ''
})

const form = reactive(formularioInicial())

// DETERMINAR SI SE EDITA
const editando = computed(() => Boolean(props.tarea))

// PREPARAR FORMULARIO
watch(
    () => [props.mostrar, props.tarea],

    () => {
        if (!props.mostrar) return

        Object.assign(form, formularioInicial())

        if (props.tarea) {
            const tarea = props.tarea

            Object.assign(form, {
                titulo: tarea.titulo || '',

                materiaId:
                    tarea.materiaId?._id ||
                    tarea.materiaId ||
                    '',

                tipo: tarea.tipo || 'Tarea',

                fechaEntrega: tarea.fechaEntrega
                    ? String(tarea.fechaEntrega).slice(0, 10)
                    : '',

                horaEntrega: tarea.horaEntrega || '',

                prioridad: tarea.prioridad || 'Media',

                estado: tarea.estado || 'Pendiente',

                notas: tarea.notas || ''
            })
        }
    },

    { immediate: true }
)

// CERRAR MODAL
const cerrar = () => {
    if (props.guardando) return

    emit('cerrar')
}

// GUARDAR TAREA
const guardar = () => {
    if (props.guardando) return

    if (!form.titulo.trim()) return

    const datos = {
        titulo: form.titulo.trim(),

        materiaId: form.materiaId || null,

        tipo: form.tipo,

        fechaEntrega: form.fechaEntrega || null,

        horaEntrega: form.horaEntrega || '',

        prioridad: form.prioridad,

        estado: form.estado,

        notas: form.notas.trim()
    }

    emit('guardar', datos)
}
</script>

<style scoped>
.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(22, 45, 37, .55);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    z-index: 1000;
}

.tarea-modal {
    background: white;
    width: 100%;
    max-width: 650px;
    max-height: 90vh;
    overflow-y: auto;
    border-radius: 18px;
    padding: 30px;
    box-shadow: 0 20px 60px rgba(0,0,0,.15);
    box-sizing: border-box;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 25px;
    gap: 15px;
}

.modal-eyebrow {
    font-size: 11px;
    letter-spacing: 1px;
    color: #78917c;
}

.modal-header h2 {
    color: #25443a;
    margin: 8px 0;
}

.modal-header p {
    color: #82938b;
    margin: 0;
}

.modal-close {
    border: 0;
    background: transparent;
    font-size: 27px;
    cursor: pointer;
    color: #587467;
    align-self: flex-start;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 18px;
    flex: 1;
    min-width: 0;
}

.form-group label {
    color: #345649;
    font-size: 13px;
    font-weight: 600;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    box-sizing: border-box;
    padding: 12px;
    border: 1px solid #dce5dc;
    border-radius: 9px;
    background: #fbfcfa;
    color: #29473c;
    font: inherit;
    outline-color: #78917c;
}

.form-group textarea {
    resize: vertical;
}

.form-row {
    display: flex;
    gap: 16px;
}

.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 25px;
}

.btn-primary,
.btn-secondary {
    border-radius: 9px;
    padding: 12px 19px;
    cursor: pointer;
    font-weight: 600;
}

.btn-primary {
    background: #426b59;
    color: white;
    border: 1px solid #426b59;
}

.btn-secondary {
    background: white;
    color: #426b59;
    border: 1px solid #dce5dc;
}

.btn-primary:disabled {
    opacity: .6;
    cursor: not-allowed;
}

@media (max-width: 550px) {
    .form-row {
        flex-direction: column;
        gap: 0;
    }

    .tarea-modal {
        padding: 20px;
    }
}
</style>
