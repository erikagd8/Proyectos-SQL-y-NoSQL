
<template>
    <!-- PANTALLAS PÚBLICAS: LOGIN Y REGISTRO -->
    <RouterView v-if="esRutaPublica" />

    <!-- APLICACIÓN PRINCIPAL -->
    <div v-else class="app-layout">

        <!-- FONDO OSCURO PARA MÓVILES -->
        <div
            v-if="menuAbierto && esMovil"
            class="sidebar-overlay"
            @click="cerrarMenu"
        ></div>

        <!-- MENÚ LATERAL -->
        <aside
            :class="[
                'sidebar',
                {
                    'sidebar-collapsed': !menuAbierto && !esMovil,
                    'sidebar-open': menuAbierto && esMovil
                }
            ]"
        >

            <!-- LOGOTIPO -->
            <div class="brand">

                <div class="brand-icon">S</div>

                <div class="brand-info">
                    <h2>StudySpace</h2>
                </div>

                <!-- CERRAR MENÚ EN MÓVIL -->
                <button
                    class="close-menu"
                    @click="cerrarMenu"
                    aria-label="Cerrar menú"
                >
                    ×
                </button>

            </div>

            <div class="menu-label">MENÚ PRINCIPAL</div>

            <!-- NAVEGACIÓN -->
            <nav class="navigation">

                <RouterLink
                    to="/"
                    class="nav-link"
                    exact-active-class="active"
                    @click="cerrarMenuMovil"
                    title="Inicio"
                >
                    <span>⌂</span>
                    <span class="nav-text">Inicio</span>
                </RouterLink>

                <RouterLink
                    to="/periodos"
                    class="nav-link"
                    @click="cerrarMenuMovil"
                    title="Periodos académicos"
                >
                    <span>◷</span>
                    <span class="nav-text">Periodos académicos</span>
                </RouterLink>

                <RouterLink
                    to="/materias"
                    class="nav-link"
                    @click="cerrarMenuMovil"
                    title="Mis materias"
                >
                    <span>▤</span>
                    <span class="nav-text">Mis materias</span>
                </RouterLink>

                <RouterLink
                    to="/tareas"
                    class="nav-link"
                    @click="cerrarMenuMovil"
                    title="Mis tareas"
                >
                    <span>✓</span>
                    <span class="nav-text">Mis tareas</span>
                </RouterLink>

            </nav>

            <!-- PERFIL Y CIERRE DE SESIÓN -->
            <div class="sidebar-bottom">

                <div class="profile">

                    <div class="profile-avatar">
                        {{ inicialesUsuario }}
                    </div>

                    <div class="profile-info">
                        <strong>{{ nombreUsuario }}</strong>
                        <small>{{ correoUsuario }}</small>
                    </div>

                </div>

                <!-- BOTÓN CERRAR SESIÓN -->
                <button
                    class="logout-button"
                    @click="cerrarSesion"
                    :disabled="cerrandoSesion"
                    title="Cerrar sesión"
                >
                    <span>↪</span>

                    <span class="nav-text">
                        {{ cerrandoSesion ? 'Cerrando...' : 'Cerrar sesión' }}
                    </span>
                </button>

            </div>

        </aside>

        <!-- ÁREA PRINCIPAL -->
        <main
            :class="[
                'main-area',
                { 'main-expanded': !menuAbierto && !esMovil }
            ]"
        >

            <!-- BARRA SUPERIOR -->
            <header class="topbar">

                <div class="topbar-left">

                    <!-- BOTÓN ABRIR / CERRAR MENÚ -->
                    <button
                        class="hamburger-btn"
                        @click="alternarMenu"
                        :aria-expanded="menuAbierto"
                        aria-label="Abrir o cerrar menú"
                        title="Abrir o cerrar menú"
                    >
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>

                    <div>
                        <span class="topbar-subtitle">
                            STUDYSPACE / PERSONAL
                        </span>

                        <h3>Mi espacio académico</h3>
                    </div>

                </div>

                <div class="topbar-date">
                    Organiza. Aprende. Avanza.
                </div>

            </header>

            <!-- CONTENIDO DE LAS VISTAS -->
            <div class="page-content">
                <RouterView />
            </div>

        </main>

    </div>
</template>

<script setup>

import { 
    ref, 
    computed, 
    onMounted, 
    onUnmounted, 
    watch 
} from 'vue'

import {
    RouterLink,
    RouterView,
    useRoute,
    useRouter
} from 'vue-router'

import { authService } from './services/authService'

// ROUTER
const route = useRoute()
const router = useRouter()

// ESTADO DEL MENÚ
const menuAbierto = ref(true)
const esMovil = ref(window.innerWidth <= 600)

// INFORMACIÓN DEL USUARIO
const usuario = ref(null)
const cerrandoSesion = ref(false)

// IDENTIFICAR PANTALLAS PÚBLICAS
const esRutaPublica = computed(() => {
    return route.meta.publica === true
})

// NOMBRE DEL USUARIO
const nombreUsuario = computed(() => {
    return usuario.value?.nombre || 'Estudiante'
})

// CORREO DEL USUARIO
const correoUsuario = computed(() => {
    return usuario.value?.correo || ''
})

// INICIALES DEL USUARIO
const inicialesUsuario = computed(() => {

    const nombre = usuario.value?.nombre || 'Estudiante'

    return nombre
        .trim()
        .split(/\s+/)
        .slice(0, 2)
        .map(palabra => palabra.charAt(0))
        .join('')
        .toUpperCase()

})

// CONSULTAR USUARIO ACTUAL
const cargarUsuario = async () => {

    if (esRutaPublica.value) {
        usuario.value = null
        return
    }

    try {

        const respuesta = await authService.obtenerSesion()

        usuario.value = respuesta.usuario

    } catch (error) {

        usuario.value = null

        if (route.name !== 'login') {
            await router.replace('/login')
        }

    }

}

// ABRIR Y CERRAR MENÚ
const alternarMenu = () => {
    menuAbierto.value = !menuAbierto.value
}

// CERRAR MENÚ
const cerrarMenu = () => {
    menuAbierto.value = false
}

// CERRAR SOLO EN MÓVIL AL CAMBIAR DE PÁGINA
const cerrarMenuMovil = () => {

    if (esMovil.value) {
        cerrarMenu()
    }

}

// CERRAR SESIÓN
const cerrarSesion = async () => {

    if (cerrandoSesion.value) return

    cerrandoSesion.value = true

    try {

        await authService.cerrarSesion()

        usuario.value = null

        await router.replace('/login')

    } catch (error) {

        console.error('Error al cerrar sesión:', error)

        window.alert(
            'No se pudo cerrar la sesión. Intenta nuevamente.'
        )

    } finally {

        cerrandoSesion.value = false

    }

}

// DETECTAR TAMAÑO DE PANTALLA
const manejarResize = () => {

    const movil = window.innerWidth <= 600

    if (movil !== esMovil.value) {

        esMovil.value = movil

        menuAbierto.value = !movil

    }

}

// CERRAR CON ESCAPE
const manejarTecla = (evento) => {

    if (evento.key === 'Escape' && esMovil.value) {
        cerrarMenu()
    }

}

// BLOQUEAR SCROLL DEL FONDO EN MÓVILES
watch(
    [menuAbierto, esMovil],

    ([abierto, movil]) => {

        document.body.style.overflow =
            abierto && movil ? 'hidden' : ''

    },

    { immediate: true }
)

// ACTUALIZAR USUARIO CUANDO CAMBIA LA RUTA
watch(
    () => route.fullPath,

    () => {

        if (esRutaPublica.value) {
            usuario.value = null
        } else {
            cargarUsuario()
        }

    }
)

// INICIALIZACIÓN
onMounted(() => {

    cargarUsuario()

    window.addEventListener('resize', manejarResize)

    window.addEventListener('keydown', manejarTecla)

})

// LIMPIAR EVENTOS
onUnmounted(() => {

    window.removeEventListener('resize', manejarResize)

    window.removeEventListener('keydown', manejarTecla)

    document.body.style.overflow = ''

})

</script>

<style>

/* CONFIGURACIÓN GENERAL */

* {
    box-sizing: border-box;
}

.app-layout {
    min-height: 100vh;
    background: #f3f5f2;
    color: #29483d;
}

/* MENÚ LATERAL */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;

    width: 270px;
    height: 100vh;

    background: #203f36;
    color: white;

    z-index: 300;

    display: flex;
    flex-direction: column;

    padding: 28px 20px;

    overflow-x: hidden;
    overflow-y: auto;

    transition: width .3s ease, transform .3s ease;
}

/* MENÚ CONTRAÍDO */

.sidebar.sidebar-collapsed {
    width: 85px;
    padding: 28px 12px;
}

/* MARCA */

.brand {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 48px;
    min-height: 48px;
}

.brand-icon {
    width: 48px;
    height: 48px;
    min-width: 48px;

    background: #e8f0e8;
    color: #315d49;

    border-radius: 14px;

    display: grid;
    place-items: center;

    font-size: 23px;
    font-weight: 800;
}

.brand-info {
    white-space: nowrap;
    overflow: hidden;
}

.brand-info h2 {
    margin: 0 0 5px;
    font-size: 19px;
}

.brand-info span {
    font-size: 12px;
    color: #c2d3c8;
}

/* OCULTAR MARCA AL CONTRAER */

.sidebar-collapsed .brand-info {
    display: none;
}

.sidebar-collapsed .brand {
    justify-content: center;
}

/* BOTÓN CERRAR MÓVIL */

.close-menu {
    display: none;
    margin-left: auto;

    background: transparent;
    border: 0;

    color: white;
    font-size: 28px;

    cursor: pointer;
}

/* ETIQUETA MENÚ */

.menu-label {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1px;

    color: #b4cbbd;

    margin: 0 10px 17px;
    white-space: nowrap;
}

.sidebar-collapsed .menu-label {
    display: none;
}

/* NAVEGACIÓN */

.navigation {
    display: flex;
    flex-direction: column;
    gap: 9px;
}

.nav-link {
    display: flex;
    align-items: center;
    gap: 15px;

    text-decoration: none;
    color: #f1f5f0;

    padding: 16px 13px;

    border-radius: 10px;

    font-size: 14px;
    white-space: nowrap;

    transition: background .2s;
}

.nav-link > span:first-child {
    width: 20px;
    min-width: 20px;

    text-align: center;
    font-size: 19px;
}

.nav-link:hover,
.nav-link.active {
    background: #456b5b;
}

/* MENÚ CONTRAÍDO: SOLO ICONOS */

.sidebar-collapsed .nav-link {
    justify-content: center;
    padding: 16px 5px;
}

.sidebar-collapsed .nav-text {
    display: none;
}

/* PERFIL */

.sidebar-bottom {
    margin-top: auto;
    padding-top: 35px;
}

.profile {
    display: flex;
    align-items: center;
    gap: 12px;

    border-top: 1px solid #456256;

    margin-top: 25px;
    padding: 22px 5px 0;
}

.profile-avatar {
    width: 43px;
    height: 43px;
    min-width: 43px;

    background: #e1ece1;
    color: #315d49;

    border-radius: 50%;

    display: grid;
    place-items: center;

    font-weight: bold;
}

.profile-info {
    white-space: nowrap;
}

.profile strong,
.profile small {
    display: block;
}

.profile strong {
    font-size: 13px;
}

.profile small {
    font-size: 11px;
    color: #c2d3c8;
    margin-top: 3px;
}

/* PERFIL CONTRAÍDO */

.sidebar-collapsed .profile {
    justify-content: center;
}

.sidebar-collapsed .profile-info {
    display: none;
}

/* ÁREA PRINCIPAL */

.main-area {
    min-height: 100vh;
    margin-left: 270px;

    transition: margin-left .3s ease;
}

.main-area.main-expanded {
    margin-left: 85px;
}

/* BARRA SUPERIOR */

.topbar {
    height: 82px;

    padding: 0 32px;

    background: white;
    border-bottom: 1px solid #e5ebe4;

    display: flex;
    justify-content: space-between;
    align-items: center;

    position: sticky;
    top: 0;

    z-index: 100;
}

.topbar-left {
    display: flex;
    align-items: center;
    gap: 20px;
}

.topbar-subtitle {
    font-size: 11px;
    color: #78917c;
    letter-spacing: 1px;
}

.topbar h3 {
    margin: 6px 0 0;
    font-size: 17px;
}

.topbar-date {
    color: #78917c;
    font-size: 13px;
}

/* BOTÓN HAMBURGUESA */

.hamburger-btn {
    width: 43px;
    height: 43px;

    border: 1px solid #e1e9e1;
    border-radius: 10px;

    background: white;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 5px;

    cursor: pointer;

    transition: background .2s;
}

.hamburger-btn:hover {
    background: #edf3ed;
}

.hamburger-btn span {
    width: 19px;
    height: 2px;

    background: #345c49;
    border-radius: 3px;
}

/* CONTENIDO */

.page-content {
    padding: 0;
    min-height: calc(100vh - 82px);
}

/* FONDO OSCURO PARA MÓVILES */

.sidebar-overlay {
    position: fixed;
    inset: 0;

    background: rgba(12, 29, 23, .48);

    z-index: 250;
}

/* RESPONSIVE: CELULARES */

@media (max-width: 600px) {

    .sidebar {
        width: min(290px, 85vw);
        padding: 28px 20px;

        transform: translateX(-100%);
    }

    .sidebar.sidebar-open {
        transform: translateX(0);
    }

    /* Restaurar textos en móvil */

    .sidebar .brand-info,
    .sidebar .nav-text,
    .sidebar .profile-info,
    .sidebar .menu-label {
        display: block;
    }

    .sidebar .brand {
        justify-content: flex-start;
    }

    .sidebar .nav-link {
        justify-content: flex-start;
        padding: 16px 13px;
    }

    .sidebar .profile {
        justify-content: flex-start;
    }

    .close-menu {
        display: block;
    }

    .main-area,
    .main-area.main-expanded {
        margin-left: 0;
    }

    .topbar {
        height: 72px;
        padding: 0 15px;
    }

    .topbar-left {
        gap: 12px;
    }

    .topbar-date {
        display: none;
    }

    .topbar h3 {
        font-size: 15px;
    }
}

/* TABLETS */

@media (min-width: 601px) and (max-width: 900px) {

    .sidebar {
        width: 230px;
        padding: 25px 15px;
    }

    .sidebar.sidebar-collapsed {
        width: 85px;
    }

    .main-area {
        margin-left: 230px;
    }

    .main-area.main-expanded {
        margin-left: 85px;
    }

    .topbar {
        padding: 0 20px;
    }
}

/* CORRECCIÓN DEL MENÚ LATERAL */

.sidebar {
    width: 270px !important;
    min-width: 270px;
    transition: width .3s ease, padding .3s ease;
}

/* MENÚ CERRADO */
.sidebar.sidebar-collapsed {
    width: 85px !important;
    min-width: 85px;
    padding: 28px 12px;
}

/* CONTENIDO CON MENÚ ABIERTO */
.main-area {
    margin-left: 270px !important;
    width: calc(100% - 270px);
    transition: width .3s ease, margin-left .3s ease;
}

/* CONTENIDO CON MENÚ CERRADO */
.main-area.main-expanded {
    margin-left: 85px !important;
    width: calc(100% - 85px);
}

/* RESPONSIVE */
@media (max-width: 600px) {
    .sidebar {
        width: min(290px, 85vw) !important;
        min-width: 0;
    }

    .main-area,
    .main-area.main-expanded {
        margin-left: 0 !important;
        width: 100%;
    }
}

/* BOTÓN CERRAR SESIÓN */

.logout-button {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 15px;

    margin-top: 15px;
    padding: 14px 13px;

    background: transparent;
    border: none;
    border-radius: 10px;

    color: #f1f5f0;
    font-size: 14px;
    font-family: inherit;
    text-align: left;

    cursor: pointer;

    transition: background .2s;
}

.logout-button:hover {
    background: rgba(220, 80, 80, .20);
}

.logout-button:disabled {
    opacity: .6;
    cursor: wait;
}

.logout-button > span:first-child {
    width: 20px;
    min-width: 20px;
    text-align: center;
    font-size: 19px;
}

.sidebar-collapsed .logout-button {
    justify-content: center;
    padding: 16px 5px;
}

.sidebar-collapsed .logout-button .nav-text {
    display: none;
}

/* VISTA MÓVIL */

@media (max-width: 600px) {

    .sidebar .logout-button {
        justify-content: flex-start;
        padding: 16px 13px;
    }

    .sidebar .logout-button .nav-text {
        display: block;
    }

}

</style>
