const mongoose = require('mongoose')

const Tarea = require('../models/Tarea')
const Materia = require('../models/Materia')

// ==========================================
// OBTENER TODAS LAS TAREAS
// ==========================================

const obtenerTareas = async (req, res) => {
    try {
        const {
            materiaId,
            estado,
            prioridad,
            tipo,
            busqueda
        } = req.query

        const filtro = {}

        // Filtrar por materia
        if (materiaId === 'general') {
            filtro.materiaId = null

        } else if (materiaId) {

            if (!mongoose.isValidObjectId(materiaId)) {
                return res.status(400).json({
                    success: false,
                    mensaje: 'Identificador de materia inválido'
                })
            }

            filtro.materiaId = materiaId
        }

        // Filtrar por estado
        const estadosPermitidos = [
            'Pendiente',
            'En progreso',
            'Completada'
        ]

        if (estado) {
            if (!estadosPermitidos.includes(estado)) {
                return res.status(400).json({
                    success: false,
                    mensaje: 'Estado no válido'
                })
            }

            filtro.estado = estado
        }

        // Filtrar por prioridad
        const prioridadesPermitidas = [
            'Baja',
            'Media',
            'Alta'
        ]

        if (prioridad) {
            if (!prioridadesPermitidas.includes(prioridad)) {
                return res.status(400).json({
                    success: false,
                    mensaje: 'Prioridad no válida'
                })
            }

            filtro.prioridad = prioridad
        }

        // Filtrar por tipo de actividad
        const tiposPermitidos = [
            'Tarea',
            'Examen',
            'Exposición',
            'Proyecto',
            'Lectura',
            'Otro'
        ]

        if (tipo) {
            if (!tiposPermitidos.includes(tipo)) {
                return res.status(400).json({
                    success: false,
                    mensaje: 'Tipo de actividad no válido'
                })
            }

            filtro.tipo = tipo
        }

        // Buscar por título
        if (busqueda && busqueda.trim()) {

            const texto = busqueda.trim().replace(
                /[.*+?^${}()|[\]\\]/g,
                '\\$&'
            )

            filtro.titulo = {
                $regex: texto,
                $options: 'i'
            }
        }

        // Consultar MongoDB
        const tareas = await Tarea.find(filtro)
            .populate('materiaId', 'nombre color')
            .sort({
                fechaEntrega: 1,
                createdAt: -1
            })

        return res.status(200).json({
            success: true,
            total: tareas.length,
            tareas
        })

    } catch (error) {

        console.error('Error al obtener tareas:', error)

        return res.status(500).json({
            success: false,
            mensaje: 'Error al obtener las tareas',
            error: error.message
        })
    }
}


// ==========================================
// OBTENER UNA TAREA POR ID
// ==========================================

const obtenerTarea = async (req, res) => {
    try {
        const { id } = req.params

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                mensaje: 'Identificador inválido'
            })
        }

        const tarea = await Tarea.findById(id)
            .populate('materiaId', 'nombre color')

        if (!tarea) {
            return res.status(404).json({
                success: false,
                mensaje: 'Tarea no encontrada'
            })
        }

        return res.json({
            success: true,
            tarea
        })

    } catch (error) {

        console.error('Error al obtener tarea:', error)

        return res.status(500).json({
            success: false,
            mensaje: 'Error al obtener la tarea',
            error: error.message
        })
    }
}


// ==========================================
// CREAR UNA TAREA
// ==========================================

const crearTarea = async (req, res) => {
    try {
        const {
            titulo,
            materiaId,
            tipo,
            fechaEntrega,
            horaEntrega,
            prioridad,
            estado,
            notas
        } = req.body

        // Validar título
        if (!titulo || !titulo.trim()) {
            return res.status(400).json({
                success: false,
                mensaje: 'El título es obligatorio'
            })
        }

        // Validar materia si fue seleccionada
        if (materiaId) {

            if (!mongoose.isValidObjectId(materiaId)) {
                return res.status(400).json({
                    success: false,
                    mensaje: 'Identificador de materia inválido'
                })
            }

            const materia = await Materia.findById(materiaId)

            if (!materia || materia.estado !== 'Activa') {
                return res.status(404).json({
                    success: false,
                    mensaje: 'La materia no existe o no está activa'
                })
            }
        }

        // Crear documento
        const tarea = await Tarea.create({
            titulo: titulo.trim(),
            materiaId: materiaId || null,
            tipo,
            fechaEntrega: fechaEntrega || null,
            horaEntrega,
            prioridad,
            estado,
            notas
        })

        // Obtener tarea con información de materia
        const tareaCompleta = await Tarea.findById(tarea._id)
            .populate('materiaId', 'nombre color')

        return res.status(201).json({
            success: true,
            mensaje: 'Tarea creada correctamente',
            tarea: tareaCompleta
        })

        } catch (error) {
        console.error('ERROR AL CREAR TAREA:', error)

        res.status(400).json({
            success: false,
            mensaje: 'No fue posible crear la tarea',
            error: error.message
        })
    }
}


// ==========================================
// ACTUALIZAR UNA TAREA
// ==========================================

const actualizarTarea = async (req, res) => {
    try {
        const { id } = req.params

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                mensaje: 'Identificador inválido'
            })
        }

        const tarea = await Tarea.findById(id)

        if (!tarea) {
            return res.status(404).json({
                success: false,
                mensaje: 'Tarea no encontrada'
            })
        }

        const datos = { ...req.body }

        // Validar materia si se modifica
        if (
            Object.prototype.hasOwnProperty.call(
                datos,
                'materiaId'
            )
        ) {

            if (datos.materiaId) {

                if (!mongoose.isValidObjectId(datos.materiaId)) {
                    return res.status(400).json({
                        success: false,
                        mensaje: 'Identificador de materia inválido'
                    })
                }

                const materia = await Materia.findById(
                    datos.materiaId
                )

                if (!materia || materia.estado !== 'Activa') {
                    return res.status(404).json({
                        success: false,
                        mensaje: 'La materia no existe o no está activa'
                    })
                }

            } else {
                datos.materiaId = null
            }
        }

        // Evitar modificar campos internos
        delete datos._id
        delete datos.createdAt
        delete datos.updatedAt
        delete datos.__v

        // Actualizar documento
        const tareaActualizada = await Tarea.findByIdAndUpdate(
            id,
            datos,
            {
                new: true,
                runValidators: true
            }
        ).populate('materiaId', 'nombre color')

        return res.json({
            success: true,
            mensaje: 'Tarea actualizada correctamente',
            tarea: tareaActualizada
        })

    } catch (error) {

        console.error('Error al actualizar tarea:', error)

        return res.status(400).json({
            success: false,
            mensaje: 'No fue posible actualizar la tarea',
            error: error.message
        })
    }
}


// ==========================================
// CAMBIAR ESTADO DE UNA TAREA
// ==========================================

const cambiarEstado = async (req, res) => {
    try {
        const { id } = req.params
        const { estado } = req.body

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                mensaje: 'Identificador inválido'
            })
        }

        const estadosPermitidos = [
            'Pendiente',
            'En progreso',
            'Completada'
        ]

        if (!estadosPermitidos.includes(estado)) {
            return res.status(400).json({
                success: false,
                mensaje: 'Estado no válido'
            })
        }

        const tarea = await Tarea.findByIdAndUpdate(
            id,
            { estado },
            {
                new: true,
                runValidators: true
            }
        ).populate('materiaId', 'nombre color')

        if (!tarea) {
            return res.status(404).json({
                success: false,
                mensaje: 'Tarea no encontrada'
            })
        }

        return res.json({
            success: true,
            mensaje: 'Estado actualizado correctamente',
            tarea
        })

    } catch (error) {

        console.error('Error al cambiar estado:', error)

        return res.status(500).json({
            success: false,
            mensaje: 'Error al cambiar el estado',
            error: error.message
        })
    }
}


// ==========================================
// ELIMINAR UNA TAREA
// ==========================================

const eliminarTarea = async (req, res) => {
    try {
        const { id } = req.params

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                mensaje: 'Identificador inválido'
            })
        }

        const tarea = await Tarea.findByIdAndDelete(id)

        if (!tarea) {
            return res.status(404).json({
                success: false,
                mensaje: 'Tarea no encontrada'
            })
        }

        return res.json({
            success: true,
            mensaje: 'Tarea eliminada correctamente'
        })

    } catch (error) {

        console.error('Error al eliminar tarea:', error)

        return res.status(500).json({
            success: false,
            mensaje: 'Error al eliminar la tarea',
            error: error.message
        })
    }
}


const obtenerResumenTareasPorEstado = async (req, res) => {
    try {
        const resumen = await Tarea.aggregate([
            {
                $group: {
                    _id: {
                        $ifNull: ["$estado", "Sin estado"]
                    },
                    total: {
                        $sum: 1
                    }
                }
            },
            {
                $sort: {
                    _id: 1
                }
            }
        ]);

        return res.status(200).json({
            success: true,
            mensaje: "Resumen de tareas obtenido correctamente",
            resumen
        });

    } catch (error) {
        console.error("Error al generar resumen:", error);

        return res.status(500).json({
            success: false,
            mensaje: "Error al generar el resumen de tareas",
            error: error.message
        });
    }
};

// ==========================================
// EXPORTAR CONTROLADORES
// ==========================================

module.exports = {
    obtenerTareas,
    obtenerTarea,
    crearTarea,
    actualizarTarea,
    cambiarEstado,
    eliminarTarea,
    obtenerResumenTareasPorEstado
}
