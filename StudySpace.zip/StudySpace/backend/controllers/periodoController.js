
const mongoose = require('mongoose')
const Periodo = require('../models/Periodo')
const Materia = require('../models/Materia')

// OBTENER TODOS LOS PERIODOS
const obtenerPeriodos = async (req, res) => {
    try {
        const periodos = await Periodo.find()
            .sort({ fechaInicio: -1 })

        return res.json({
            success: true,
            periodos
        })
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: 'Error al consultar los periodos.'
        })
    }
}

// OBTENER UN PERIODO
const obtenerPeriodo = async (req, res) => {
    try {
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de periodo inválido.'
            })
        }

        const periodo = await Periodo.findById(req.params.id)

        if (!periodo) {
            return res.status(404).json({
                success: false,
                error: 'Periodo no encontrado.'
            })
        }

        return res.json({
            success: true,
            periodo
        })
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: error.message
        })
    }
}

// REGISTRAR PERIODO
const crearPeriodo = async (req, res) => {
    try {
        const {
            nombre,
            tipo,
            numero,
            fechaInicio,
            fechaFin,
            estado
        } = req.body

        if (
            !nombre?.trim() ||
            !tipo ||
            !numero ||
            !fechaInicio ||
            !fechaFin
        ) {
            return res.status(400).json({
                success: false,
                error: 'Completa todos los campos obligatorios.'
            })
        }

        if (new Date(fechaInicio) > new Date(fechaFin)) {
            return res.status(400).json({
                success: false,
                error: 'La fecha de inicio no puede ser posterior a la fecha final.'
            })
        }

        const periodo = await Periodo.create({
            nombre: nombre.trim(),
            tipo,
            numero,
            fechaInicio,
            fechaFin,
            estado: estado || 'Planeado'
        })

        return res.status(201).json({
            success: true,
            mensaje: 'Periodo registrado correctamente.',
            periodo
        })
    } catch (error) {
        if (error.code === 11000) {
            return res.status(409).json({
                success: false,
                error: 'Ya existe un periodo con ese nombre.'
            })
        }

        return res.status(400).json({
            success: false,
            error: error.message || 'No se pudo registrar el periodo.'
        })
    }
}

// ACTUALIZAR PERIODO
const actualizarPeriodo = async (req, res) => {
    try {
        const { id } = req.params
        const datos = req.body

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de periodo inválido.'
            })
        }

        if (
            !datos.nombre?.trim() ||
            !datos.tipo ||
            !datos.numero ||
            !datos.fechaInicio ||
            !datos.fechaFin
        ) {
            return res.status(400).json({
                success: false,
                error: 'Completa todos los campos obligatorios.'
            })
        }

        if (new Date(datos.fechaInicio) > new Date(datos.fechaFin)) {
            return res.status(400).json({
                success: false,
                error: 'La fecha de inicio no puede ser posterior a la fecha final.'
            })
        }

        const periodo = await Periodo.findByIdAndUpdate(
            id,
            datos,
            {
                new: true,
                runValidators: true
            }
        )

        if (!periodo) {
            return res.status(404).json({
                success: false,
                error: 'Periodo no encontrado.'
            })
        }

        return res.json({
            success: true,
            mensaje: 'Periodo actualizado correctamente.',
            periodo
        })
    } catch (error) {
        if (error.code === 11000) {
            return res.status(409).json({
                success: false,
                error: 'Ya existe un periodo con ese nombre.'
            })
        }

        return res.status(400).json({
            success: false,
            error: error.message || 'No se pudo actualizar el periodo.'
        })
    }
}

// ELIMINAR PERIODO
const eliminarPeriodo = async (req, res) => {
    try {
        const { id } = req.params

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de periodo inválido.'
            })
        }

        const periodo = await Periodo.findById(id)

        if (!periodo) {
            return res.status(404).json({
                success: false,
                error: 'Periodo no encontrado.'
            })
        }

        // Comprobar si existen materias asociadas.
        const materiasAsociadas = await Materia.countDocuments({
            periodo: id
        })

        if (materiasAsociadas > 0) {
            return res.status(409).json({
                success: false,
                error: `No se puede eliminar este periodo porque tiene ${materiasAsociadas} materia(s) asociada(s). Primero elimina o cambia de periodo esas materias.`
            })
        }

        await Periodo.findByIdAndDelete(id)

        return res.json({
            success: true,
            mensaje: 'Periodo eliminado correctamente.'
        })
    } catch (error) {
        console.error('Error al eliminar periodo:', error)

        return res.status(500).json({
            success: false,
            error: 'No se pudo eliminar el periodo.',
            detalle: error.message
        })
    }
}

module.exports = {
    obtenerPeriodos,
    obtenerPeriodo,
    crearPeriodo,
    actualizarPeriodo,
    eliminarPeriodo
}
