
const mongoose = require('mongoose')
const Materia = require('../models/Materia')
const Periodo = require('../models/Periodo')
const Tarea = require('../models/Tarea')

// OBTENER TODAS LAS MATERIAS
const obtenerMaterias = async (req, res) => {
    try {
        const { periodo, estado } = req.query
        const filtros = {}

        if (periodo) filtros.periodo = periodo
        if (estado) filtros.estado = estado

        const materias = await Materia.find(filtros)
            .populate('periodo', 'nombre tipo numero')
            .sort({ createdAt: -1 })

        return res.json({
            success: true,
            materias
        })
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: error.message
        })
    }
}

// OBTENER UNA MATERIA
const obtenerMateria = async (req, res) => {
    try {
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de materia inválido'
            })
        }

        const materia = await Materia.findById(req.params.id)
            .populate('periodo', 'nombre tipo numero')

        if (!materia) {
            return res.status(404).json({
                success: false,
                error: 'Materia no encontrada'
            })
        }

        return res.json({
            success: true,
            materia
        })
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: error.message
        })
    }
}

// CREAR MATERIA
const crearMateria = async (req, res) => {
    try {
        const { nombre, docente, color, periodo } = req.body

        if (!nombre || !nombre.trim()) {
            return res.status(400).json({
                success: false,
                error: 'El nombre de la materia es obligatorio'
            })
        }

        if (!periodo || !mongoose.isValidObjectId(periodo)) {
            return res.status(400).json({
                success: false,
                error: 'Debes seleccionar un periodo académico válido'
            })
        }

        const periodoExiste = await Periodo.findById(periodo)

        if (!periodoExiste) {
            return res.status(404).json({
                success: false,
                error: 'El periodo académico no existe'
            })
        }

        const materia = await Materia.create({
            nombre: nombre.trim(),
            docente,
            color,
            periodo
        })

        const materiaGuardada = await Materia.findById(materia._id)
            .populate('periodo', 'nombre tipo numero')

        return res.status(201).json({
            success: true,
            mensaje: 'Materia registrada correctamente',
            materia: materiaGuardada
        })
    } catch (error) {
        return res.status(400).json({
            success: false,
            error: error.message
        })
    }
}

// ACTUALIZAR MATERIA
const actualizarMateria = async (req, res) => {
    try {
        const { nombre, docente, color, periodo } = req.body
        const { id } = req.params
        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de materia inválido'
            })
        }
        if (!nombre || !nombre.trim() || !periodo) {
            return res.status(400).json({
                success: false,
                error: 'El nombre y el periodo son obligatorios'
            })
        }
        if (!mongoose.isValidObjectId(periodo)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de periodo inválido'
            })
        }
        const periodoExiste = await Periodo.findById(periodo)

        if (!periodoExiste) {
            return res.status(404).json({
                success: false,
                error: 'El periodo académico no existe'
            })
        }
        const materia = await Materia.findByIdAndUpdate(
            id,
            {
                nombre: nombre.trim(),
                docente,
                color,
                periodo
            },
            {
                new: true,
                runValidators: true
            }
        ).populate('periodo', 'nombre tipo numero')

        if (!materia) {
            return res.status(404).json({
                success: false,
                error: 'Materia no encontrada'
            })
        }
        return res.json({
            success: true,
            mensaje: 'Materia actualizada correctamente',
            materia
        })
    } catch (error) {
        return res.status(400).json({
            success: false,
            error: error.message
        })
    }
}

// CAMBIAR ESTADO DE MATERIA
const cambiarEstadoMateria = async (req, res) => {
    try {
        const { id } = req.params
        const { estado } = req.body

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de materia inválido'
            })
        }

        if (!['Activa', 'Finalizada'].includes(estado)) {
            return res.status(400).json({
                success: false,
                error: 'Estado no válido'
            })
        }

        const materia = await Materia.findByIdAndUpdate(
            id,
            { estado },
            {
                new: true,
                runValidators: true
            }
        ).populate('periodo', 'nombre tipo numero')

        if (!materia) {
            return res.status(404).json({
                success: false,
                error: 'Materia no encontrada'
            })
        }

        return res.json({
            success: true,
            mensaje: 'Estado actualizado correctamente',
            materia
        })
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: error.message
        })
    }
}

// ELIMINAR MATERIA
const eliminarMateria = async (req, res) => {
    try {
        const { id } = req.params

        if (!mongoose.isValidObjectId(id)) {
            return res.status(400).json({
                success: false,
                error: 'Identificador de materia inválido'
            })
        }

        const materia = await Materia.findById(id)

        if (!materia) {
            return res.status(404).json({
                success: false,
                error: 'Materia no encontrada'
            })
        }

        // Conservar las tareas y convertirlas en actividades generales.
        const resultado = await Tarea.updateMany(
            { materiaId: materia._id },
            { $set: { materiaId: null } }
        )

        await Materia.findByIdAndDelete(id)

        const tareasDesvinculadas =
            resultado.modifiedCount ?? resultado.nModified ?? 0

        return res.json({
            success: true,
            mensaje: 'Materia eliminada correctamente. Las tareas asociadas se conservaron como generales.',
            tareasDesvinculadas
        })
    } catch (error) {
        console.error('Error al eliminar materia:', error)

        return res.status(500).json({
            success: false,
            error: 'No fue posible eliminar la materia',
            detalle: error.message
        })
    }
}

module.exports = {
    obtenerMaterias,
    obtenerMateria,
    crearMateria,
    actualizarMateria,
    cambiarEstadoMateria,
    eliminarMateria
}
