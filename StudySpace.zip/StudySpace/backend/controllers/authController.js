const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const Usuario = require('../models/Usuario')

const COOKIE_NAME = 'studyspace_token'

const opcionesCookie = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 8 * 60 * 60 * 1000
}

// GENERAR TOKEN
const generarToken = (usuario) => {

    if (!process.env.JWT_SECRET) {
        throw new Error('Falta configurar JWT_SECRET')
    }

    return jwt.sign(
        {
            sub: usuario._id.toString()
        },
        process.env.JWT_SECRET,
        {
            expiresIn: process.env.JWT_EXPIRES_IN || '8h'
        }
    )
}

// DATOS PÚBLICOS DEL USUARIO
const datosUsuario = (usuario) => ({
    id: usuario._id,
    nombre: usuario.nombre,
    correo: usuario.correo
})

// REGISTRAR USUARIO
const registrarUsuario = async (req, res) => {
    try {

        const { nombre, correo, password } = req.body

        if (!nombre?.trim() || !correo?.trim() || !password) {
            return res.status(400).json({
                success: false,
                error: 'Todos los campos son obligatorios.'
            })
        }

        const correoNormalizado = correo.trim().toLowerCase()

        const formatoCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

        if (!formatoCorreo.test(correoNormalizado)) {
            return res.status(400).json({
                success: false,
                error: 'Introduce un correo electrónico válido.'
            })
        }

        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                error: 'La contraseña debe tener al menos 8 caracteres.'
            })
        }

        const usuarioExistente = await Usuario.findOne({
            correo: correoNormalizado
        })

        if (usuarioExistente) {
            return res.status(409).json({
                success: false,
                error: 'Este correo ya se encuentra registrado.'
            })
        }

        const passwordHash = await bcrypt.hash(password, 12)

        const usuario = await Usuario.create({
            nombre: nombre.trim(),
            correo: correoNormalizado,
            passwordHash
        })

        const token = generarToken(usuario)

        res.cookie(COOKIE_NAME, token, opcionesCookie)

        return res.status(201).json({
            success: true,
            mensaje: 'Cuenta creada correctamente.',
            usuario: datosUsuario(usuario)
        })

    } catch (error) {

        if (error.code === 11000) {
            return res.status(409).json({
                success: false,
                error: 'Este correo ya se encuentra registrado.'
            })
        }

        console.error('Error al registrar usuario:', error)

        return res.status(500).json({
            success: false,
            error: 'No se pudo registrar el usuario.'
        })
    }
}

// INICIAR SESIÓN
const iniciarSesion = async (req, res) => {
    try {

        const { correo, password } = req.body

        if (!correo?.trim() || !password) {
            return res.status(400).json({
                success: false,
                error: 'Ingresa tu correo y contraseña.'
            })
        }

        const usuario = await Usuario.findOne({
            correo: correo.trim().toLowerCase()
        }).select('+passwordHash')

        if (!usuario) {
            return res.status(401).json({
                success: false,
                error: 'Correo o contraseña incorrectos.'
            })
        }

        if (!usuario.activo) {
            return res.status(403).json({
                success: false,
                error: 'Esta cuenta se encuentra desactivada.'
            })
        }

        const passwordCorrecta = await bcrypt.compare(
            password,
            usuario.passwordHash
        )

        if (!passwordCorrecta) {
            return res.status(401).json({
                success: false,
                error: 'Correo o contraseña incorrectos.'
            })
        }

        const token = generarToken(usuario)

        res.cookie(COOKIE_NAME, token, opcionesCookie)

        return res.json({
            success: true,
            mensaje: 'Inicio de sesión correcto.',
            usuario: datosUsuario(usuario)
        })

    } catch (error) {

        console.error('Error al iniciar sesión:', error)

        return res.status(500).json({
            success: false,
            error: 'No se pudo iniciar sesión.'
        })
    }
}

// CERRAR SESIÓN
const cerrarSesion = (req, res) => {

    res.clearCookie(COOKIE_NAME, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        path: '/'
    })

    return res.json({
        success: true,
        mensaje: 'Sesión cerrada correctamente.'
    })
}

// CONSULTAR USUARIO ACTUAL
const obtenerSesion = (req, res) => {

    return res.json({
        success: true,
        usuario: datosUsuario(req.usuario)
    })
}

module.exports = {
    registrarUsuario,
    iniciarSesion,
    cerrarSesion,
    obtenerSesion
}