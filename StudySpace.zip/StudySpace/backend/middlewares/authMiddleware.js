const jwt = require('jsonwebtoken')
const Usuario = require('../models/Usuario')

const verificarSesion = async (req, res, next) => {

    try {

        const token = req.cookies?.studyspace_token

        if (!token) {
            return res.status(401).json({
                success: false,
                error: 'Debes iniciar sesión para continuar.'
            })
        }

        if (!process.env.JWT_SECRET) {
            throw new Error('Falta configurar JWT_SECRET')
        }

        const decodificado = jwt.verify(
            token,
            process.env.JWT_SECRET
        )

        const usuario = await Usuario.findById(
            decodificado.sub
        ).select('nombre correo activo')

        if (!usuario || !usuario.activo) {
            return res.status(401).json({
                success: false,
                error: 'La sesión no es válida.'
            })
        }

        req.usuarioId = usuario._id
        req.usuario = usuario

        next()

    } catch (error) {

        return res.status(401).json({
            success: false,
            error: 'Sesión expirada o inválida. Inicia sesión nuevamente.'
        })
    }
}

module.exports = verificarSesion