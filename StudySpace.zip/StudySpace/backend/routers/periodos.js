
const express = require('express')
const router = express.Router()

const {
    obtenerPeriodos,
    obtenerPeriodo,
    crearPeriodo,
    actualizarPeriodo,
    eliminarPeriodo
} = require('../controllers/periodoController')

router.get('/', obtenerPeriodos)
router.get('/:id', obtenerPeriodo)
router.post('/', crearPeriodo)
router.put('/:id', actualizarPeriodo)
router.delete('/:id', eliminarPeriodo)

module.exports = router
