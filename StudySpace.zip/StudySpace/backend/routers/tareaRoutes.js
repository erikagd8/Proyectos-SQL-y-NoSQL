
const express = require('express')
const router = express.Router()

const {
    obtenerTareas,
    obtenerTarea,
    crearTarea,
    actualizarTarea,
    cambiarEstado,
    eliminarTarea,
    obtenerResumenTareasPorEstado
} = require('../controllers/tareaController')

// CONSULTAR TAREAS
router.get('/', obtenerTareas)

// RESUMEN DE TAREAS POR ESTADO
router.get('/resumen/estados', obtenerResumenTareasPorEstado)

// CONSULTAR UNA TAREA
router.get('/:id', obtenerTarea)

// CREAR TAREA
router.post('/', crearTarea)

// ACTUALIZAR TAREA
router.put('/:id', actualizarTarea)

// CAMBIAR ESTADO
router.patch('/:id/estado', cambiarEstado)

// ELIMINAR TAREA
router.delete('/:id', eliminarTarea)

module.exports = router
