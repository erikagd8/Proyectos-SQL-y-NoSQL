const express = require('express')
const router = express.Router()

const {
    registrarUsuario,
    iniciarSesion,
    cerrarSesion,
    obtenerSesion
} = require('../controllers/authController')

const verificarSesion = require('../middlewares/authMiddleware')

// REGISTRO
router.post('/registro', registrarUsuario)

// INICIAR SESIÓN
router.post('/login', iniciarSesion)

// CERRAR SESIÓN
router.post('/logout', cerrarSesion)

// CONSULTAR SESIÓN ACTUAL
router.get('/me', verificarSesion, obtenerSesion)

module.exports = router