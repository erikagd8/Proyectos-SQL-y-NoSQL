
const express = require('express')
const router = express.Router()

const {
    obtenerMaterias,
    obtenerMateria,
    crearMateria,
    actualizarMateria,
    cambiarEstadoMateria,
    eliminarMateria
} = require('../controllers/materiaController')

// GET: consultar materias
router.get('/', obtenerMaterias)

// POST: registrar materia
router.post('/', crearMateria)

// PATCH: cambiar estado
router.patch('/:id/estado', cambiarEstadoMateria)

// GET: consultar una materia
router.get('/:id', obtenerMateria)

// PUT: actualizar materia
router.put('/:id', actualizarMateria)

// DELETE: eliminar materia
router.delete('/:id', eliminarMateria)

module.exports = router
