
const mongoose = require('mongoose')

const materiaSchema = new mongoose.Schema({

    nombre: {
        type: String,
        required: true,
        trim: true
    },

    docente: {
        type: String,
        trim: true,
        default: ''
    },

    color: {
        type: String,
        default: '#78917C'
    },

    periodo: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Periodo',
        required: true
    },

    estado: {
        type: String,
        enum: ['Activa', 'Finalizada'],
        default: 'Activa'
    }

}, {
    timestamps: true,
    collection: 'materias'
})

module.exports = mongoose.model('Materia', materiaSchema)
