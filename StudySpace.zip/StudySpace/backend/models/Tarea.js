
const mongoose = require('mongoose')

const tareaSchema = new mongoose.Schema({

    titulo: {
        type: String,
        required: true,
        trim: true,
        maxlength: 120
    },

    materiaId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Materia',
        default: null
    },

    tipo: {
        type: String,
        enum: [
            'Tarea',
            'Examen',
            'Exposición',
            'Proyecto',
            'Lectura',
            'Otro'
        ],
        default: 'Tarea'
    },

    fechaEntrega: {
        type: Date,
        default: null
    },

    horaEntrega: {
        type: String,
        default: ''
    },

    prioridad: {
        type: String,
        enum: ['Baja', 'Media', 'Alta'],
        default: 'Media'
    },

    estado: {
        type: String,
        enum: ['Pendiente', 'En progreso', 'Completada'],
        default: 'Pendiente'
    },

    notas: {
        type: String,
        trim: true,
        maxlength: 1000,
        default: ''
    }

}, {
    timestamps: true,
    versionKey: false,
    collection: 'tareas'
})

module.exports = mongoose.model('Tarea', tareaSchema)
