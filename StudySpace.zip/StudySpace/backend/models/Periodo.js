
const mongoose = require('mongoose')

const periodoSchema = new mongoose.Schema({
    nombre: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        maxlength: 50
    },

    tipo: {
        type: String,
        required: true,
        enum: ['Semestre', 'Cuatrimestre']
    },

    numero: {
        type: Number,
        required: true,
        min: 1
    },

    fechaInicio: {
        type: Date,
        required: true
    },

    fechaFin: {
        type: Date,
        required: true
    },

    estado: {
        type: String,
        enum: ['Planeado', 'Activo', 'Finalizado'],
        default: 'Planeado'
    }

}, {
    timestamps: true,
    versionKey: false
})

module.exports = mongoose.model('Periodo', periodoSchema)
