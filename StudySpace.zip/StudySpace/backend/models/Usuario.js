
const mongoose = require('mongoose')

const usuarioSchema = new mongoose.Schema({

    nombre: {
        type: String,
        required: true,
        trim: true,
        maxlength: 80
    },

    correo: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },

    passwordHash: {
        type: String,
        required: true,
        select: false
    },

    activo: {
        type: Boolean,
        default: true
    }

}, {
    timestamps: true,
    versionKey: false,
    collection: 'usuarios'
})

module.exports = mongoose.model('Usuario', usuarioSchema)
