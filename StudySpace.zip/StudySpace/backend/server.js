
require('dotenv').config()
const cookieParser = require('cookie-parser')
const express = require('express')
const cors = require('cors')
const conectarDB = require('./config/db')

const app = express()
app.use(cookieParser())

// ========================================
// MIDDLEWARES
// ========================================

app.use(cors({
    origin: [
        'http://localhost:5173',
        'http://localhost:5174'
    ],
    credentials: true
}))

app.use(express.json())

// ========================================
// RUTA PRINCIPAL
// ========================================

app.get('/', (req, res) => {
    res.json({
        success: true,
        mensaje: 'API de StudySpace funcionando correctamente'
    })
})

// ========================================
// RUTAS DE LA API
// ========================================

app.use('/api/auth', require('./routers/authRoutes'))

app.use('/api/periodos', require('./routers/periodos'))

app.use('/api/materias', require('./routers/materiaRoutes'))

app.use('/api/tareas', require('./routers/tareaRoutes'))

//app.use('/api/proyectos', require('./routers/proyectoRoutes'))

// ========================================
// RUTA PARA DIRECCIONES INEXISTENTES
// ========================================

app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Ruta no encontrada'
    })
})

// ========================================
// INICIAR SERVIDOR
// ========================================

const iniciarServidor = async () => {
    try {
        await conectarDB()

        const PUERTO = process.env.PORT || 3000

        app.listen(PUERTO, () => {
            console.log('--------------------------------')
            console.log('       STUDYSPACE API')
            console.log('--------------------------------')
            console.log('MongoDB conectado correctamente')
            console.log(`Servidor: http://localhost:${PUERTO}`)
            console.log('--------------------------------')
        })

    } catch (error) {
        console.error('Error al iniciar el servidor:', error.message)
        process.exit(1)
    }
}

iniciarServidor()
