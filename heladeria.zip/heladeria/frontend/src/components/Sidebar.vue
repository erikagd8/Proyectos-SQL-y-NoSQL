
<script setup>
defineProps({
    colapsado: Boolean,
    seccionActiva: String
})

defineEmits(['alternar', 'navegar', 'cerrar-sesion'])

const opciones = [
    { id: 'inicio', icono: '⌂', nombre: 'Inicio' },
    { id: 'productos', icono: '▦', nombre: 'Productos' },
    {
    id: 'categorias',
    nombre: 'Categorías',
    icono: '▦'
},
    { id: 'ventas', icono: '+', nombre: 'Ventas' },
    { id: 'historial', icono: '▤', nombre: 'Historial' },
    { id: 'cuenta', icono: '⚙', nombre: 'Mi cuenta' }
]
</script>

<template>
    <aside
        id="menu-lateral"
        class="sidebar"
        :class="{ 'sidebar-colapsado': colapsado }"
    >

        <header class="sidebar-encabezado">

            <div class="marca">
                <div class="marca-logo">UPA</div>
                <span v-if="!colapsado" class="marca-nombre">
                    HELADERIA
                </span>
            </div>

        </header>

        <p v-if="!colapsado" class="sidebar-subtitulo">
            ADMINISTRACIÓN
        </p>

        <nav id="sidebar-navegacion" class="sidebar-navegacion">

            <button
                v-for="opcion in opciones"
                :key="opcion.id"
                class="sidebar-enlace"
                :class="{ activo: seccionActiva === opcion.id }"
                :title="colapsado ? opcion.nombre : ''"
                @click="$emit('navegar', opcion.id)"
            >
                <span class="sidebar-icono">{{ opcion.icono }}</span>
                <span v-if="!colapsado">{{ opcion.nombre }}</span>
            </button>

        </nav>

        <footer class="sidebar-pie">

            <button
                class="sidebar-enlace cerrar-enlace"
                @click="$emit('cerrar-sesion')"
                title="Cerrar sesión"
            >
                <span class="sidebar-icono">↪</span>
                <span v-if="!colapsado">Cerrar sesión</span>
            </button>

        </footer>

    </aside>
</template>
