
<script setup>
import { ref, computed, onMounted } from 'vue'

const productos = ref([])
const carrito = ref([])
const metodoPago = ref('Efectivo')
const cargando = ref(false)
const error = ref('')
const mensaje = ref('')

const total = computed(() =>
    carrito.value.reduce((s, p) => s + p.precio * p.cantidad, 0)
)

async function cargarProductos() {
    try {
        const r = await fetch('http://localhost/heladeria/api/productos.php', {
            credentials: 'include'
        })

        const d = await r.json()

        if (!r.ok) throw new Error(d.error)

        productos.value = d.productos.filter(p => p.activo)
    } catch (e) {
        error.value = e.message
    }
}

function agregar(p) {
    const existente = carrito.value.find(
        x => x.id_producto === p.id_producto
    )

    if (existente) {
        existente.cantidad++
    } else {
        carrito.value.push({
            id_producto: p.id_producto,
            nombre: p.nombre,
            precio: Number(p.precio),
            cantidad: 1
        })
    }
}

function quitar(id) {
    carrito.value = carrito.value.filter(p => p.id_producto !== id)
}

function moneda(valor) {
    return new Intl.NumberFormat('es-MX', {
        style: 'currency',
        currency: 'MXN'
    }).format(valor)
}

async function registrarVenta() {
    error.value = ''
    mensaje.value = ''

    if (!carrito.value.length) {
        error.value = 'Agrega al menos un producto.'
        return
    }

    cargando.value = true

    try {
        const r = await fetch('http://localhost/heladeria/api/ventas.php', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                metodo_pago: metodoPago.value,
                productos: carrito.value.map(p => ({
                    id_producto: p.id_producto,
                    cantidad: p.cantidad
                }))
            })
        })

        const d = await r.json()

        if (!r.ok) throw new Error(d.error)

        mensaje.value = `Venta #${d.id_venta} registrada. Total: ${moneda(d.total)}`

        carrito.value = []

        await cargarProductos()

    } catch (e) {
        error.value = e.message
    } finally {
        cargando.value = false
    }
}

onMounted(cargarProductos)
</script>

<template>
    <section id="modulo-ventas">

        <div class="modulo-encabezado">
            <div>
                <h1>Registrar venta</h1>
                <p>Selecciona los productos que compró el cliente.</p>
            </div>
        </div>

        <p v-if="error" class="login-error">{{ error }}</p>
        <p v-if="mensaje" class="mensaje-exito">{{ mensaje }}</p>

        <div class="ventas-layout">

            <div class="productos-venta">
                <h2>Catálogo disponible</h2>

                <div class="productos-venta-grid">

                    <button
                        v-for="p in productos"
                        :key="p.id_producto"
                        class="producto-venta"
                        @click="agregar(p)"
                    >
                        <strong>{{ p.nombre }}</strong>
                        <span>{{ moneda(p.precio) }}</span>
                        <small>+ Agregar</small>
                    </button>

                </div>
            </div>

            <div class="carrito">
                <h2>Carrito de venta</h2>

                <div v-if="!carrito.length" class="carrito-vacio">
                    No hay productos agregados.
                </div>

                <div v-for="p in carrito" :key="p.id_producto" class="carrito-item">
                    <div>
                        <strong>{{ p.nombre }}</strong>
                        <small>{{ moneda(p.precio) }} por unidad</small>
                    </div>

                    <div class="cantidad-controles">
                        <button @click="p.cantidad > 1 ? p.cantidad-- : quitar(p.id_producto)">−</button>
                        <span>{{ p.cantidad }}</span>
                        <button @click="p.cantidad++">+</button>
                    </div>

                    <strong>{{ moneda(p.precio * p.cantidad) }}</strong>

                    <button class="quitar-producto" @click="quitar(p.id_producto)">×</button>
                </div>

                <div class="carrito-total">
                    <span>Total</span>
                    <strong>{{ moneda(total) }}</strong>
                </div>

                <label>Método de pago</label>
                <select v-model="metodoPago">
                    <option>Efectivo</option>
                    <option>Tarjeta</option>
                    <option>Transferencia</option>
                </select>

                <button
                    class="boton-principal boton-venta"
                    @click="registrarVenta"
                    :disabled="cargando || !carrito.length"
                >
                    {{ cargando ? 'Registrando...' : 'Confirmar venta' }}
                </button>

            </div>

        </div>

    </section>
</template>
