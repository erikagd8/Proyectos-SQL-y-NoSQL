
<template>
    <section id="modulo-productos">

        <!-- ENCABEZADO -->
        <div class="modulo-encabezado">
            <div>
                <h1>Gestión de productos</h1>
                <p>Administra el catálogo de Dulce Frío.</p>
            </div>

            <button
                class="boton-principal"
                @click="nuevoProducto"
            >
                + Nuevo producto
            </button>
        </div>

        <!-- ESTADÍSTICAS -->
        <section class="estadisticas-dashboard">

            <article class="estadistica-card">
                <span>Productos registrados</span>
                <strong>{{ productos.length }}</strong>
                <small>Productos en el catálogo</small>
            </article>

            <article class="estadistica-card">
                <span>Productos activos</span>
                <strong>{{ productos.filter(p => esActivo(p.activo)).length }}</strong>
                <small>Disponibles para venta</small>
            </article>

        </section>

        <!-- MENSAJES -->
        <p v-if="mensaje" class="mensaje-exito">
            {{ mensaje }}
        </p>

        <p v-if="error" class="login-error">
            {{ error }}
        </p>

        <!-- FILTROS -->
        <div class="filtros-productos">

            <input
                v-model="busqueda"
                type="text"
                placeholder="Buscar producto..."
            >

            <select v-model="categoriaFiltro">
                <option value="Todas">Todas las categorías</option>

                <option
                    v-for="c in categorias"
                    :key="c.id_categoria"
                    :value="String(c.id_categoria)"
                >
                    {{ c.nombre }}
                    {{ esActivo(c.activa) ? '' : '(Inactiva)' }}
                </option>
            </select>


        </div>

        <!-- TABLA -->
        <div class="tabla-contenedor">

            <table>

                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Categoría</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                    <tr
                        v-for="p in productosFiltrados"
                        :key="p.id_producto"
                    >

                        <td>
                            <strong>{{ p.nombre }}</strong>
                            <small>{{ p.descripcion || 'Sin descripción' }}</small>
                        </td>

                        <td>{{ p.categoria }}</td>

                        <td>{{ moneda(p.precio) }}</td>

                        <td>{{ p.stock }}</td>

                        <td>
                            <span
                                :class="esActivo(p.activo)
                                    ? 'estado-activo'
                                    : 'estado-inactivo'"
                            >
                                {{ esActivo(p.activo) ? 'Activo' : 'Inactivo' }}
                            </span>
                        </td>

                        <td class="acciones-tabla">

                            <button
                                class="boton-secundario"
                                @click="editarProducto(p)"
                            >
                                Editar
                            </button>

                            <button
                                class="boton-secundario"
                                @click="cambiarEstado(p)"
                            >
                                {{ esActivo(p.activo) ? 'Desactivar' : 'Activar' }}
                            </button>

                        </td>

                    </tr>

                    <tr v-if="!productosFiltrados.length && !cargando">
                        <td colspan="6">
                            No se encontraron productos.
                        </td>
                    </tr>

                </tbody>

            </table>

        </div>

        <!-- MODAL DE PRODUCTOS -->
        <div
            v-if="mostrarFormulario"
            class="modal-fondo"
            @click.self="cerrarFormulario"
        >

            <form
                class="modal-contenido"
                @submit.prevent="guardarProducto"
            >

                <h2>
                    {{ editando ? 'Editar producto' : 'Nuevo producto' }}
                </h2>

                <label for="nombre-producto">Nombre del producto</label>

                <input
                    id="nombre-producto"
                    v-model.trim="formulario.nombre"
                    type="text"
                    maxlength="100"
                    placeholder="Nombre del producto"
                    required
                >

                <label for="descripcion-producto">Descripción</label>

                <textarea
                    id="descripcion-producto"
                    v-model.trim="formulario.descripcion"
                    maxlength="255"
                    placeholder="Descripción del producto"
                ></textarea>

                <label for="categoria-producto">Categoría</label>

                <select
                    id="categoria-producto"
                    v-model="formulario.id_categoria"
                    required
                >

                    <option value="" disabled>
                        Selecciona una categoría
                    </option>

                    <option
                        v-for="c in categorias"
                        :key="c.id_categoria"
                        :value="String(c.id_categoria)"
                        :disabled="!esActivo(c.activa)"
                    >
                        {{ c.nombre }}
                        {{ esActivo(c.activa) ? '' : '(Inactiva)' }}
                    </option>

                </select>

                <label for="precio-producto">Precio</label>

                <input
                    id="precio-producto"
                    v-model.number="formulario.precio"
                    type="number"
                    min="0.01"
                    step="0.01"
                    placeholder="0.00"
                    required
                >

                <p v-if="errorFormulario" class="login-error">
                    {{ errorFormulario }}
                </p>

                <div class="modal-acciones">

                    <button
                        type="button"
                        class="boton-secundario"
                        @click="cerrarFormulario"
                    >
                        Cancelar
                    </button>

                    <button
                        class="boton-principal"
                        type="submit"
                        :disabled="guardando"
                    >
                        {{ guardando ? 'Guardando...' : 'Guardar producto' }}
                    </button>

                </div>

            </form>

        </div>

    </section>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const API = 'http://localhost/heladeria/api/'

const productos = ref([])
const categorias = ref([])

const busqueda = ref('')
const categoriaFiltro = ref('Todas')

const cargando = ref(false)
const guardando = ref(false)

const error = ref('')
const errorFormulario = ref('')
const mensaje = ref('')

const mostrarFormulario = ref(false)
const editando = ref(false)

const formulario = ref({
    id_producto: null,
    nombre: '',
    descripcion: '',
    id_categoria: '',
    precio: ''
})

// INTERPRETAR BOOLEANOS DE POSTGRESQL
function esActivo(valor) {
    return valor === true ||
           valor === 't' ||
           valor === 'true' ||
           valor === 1
}

// FILTRAR PRODUCTOS
const productosFiltrados = computed(() => {

    return productos.value.filter(p => {

        const coincideNombre = p.nombre
            .toLowerCase()
            .includes(busqueda.value.toLowerCase())

        const coincideCategoria =
            categoriaFiltro.value === 'Todas' ||
            String(p.id_categoria) === categoriaFiltro.value

        return coincideNombre && coincideCategoria

    })

})

// CARGAR PRODUCTOS
async function cargarProductos() {

    const respuesta = await fetch(
        API + 'productos.php',
        {
            credentials: 'include'
        }
    )

    const datos = await respuesta.json()

    if (!respuesta.ok) {
        throw new Error(datos.error || 'Error al cargar productos')
    }

    productos.value = datos.productos || []

}

// CARGAR CATEGORÍAS
async function cargarCategorias() {

    const respuesta = await fetch(
        API + 'categorias.php',
        {
            credentials: 'include'
        }
    )

    const datos = await respuesta.json()

    if (!respuesta.ok) {
        throw new Error(datos.error || 'Error al cargar categorías')
    }

    categorias.value = datos.categorias || []

}

// ACTUALIZAR INFORMACIÓN
async function cargarDatos() {

    cargando.value = true
    error.value = ''

    try {

        await Promise.all([
            cargarProductos(),
            cargarCategorias()
        ])

    } catch (e) {

        error.value = e.message

    } finally {

        cargando.value = false

    }

}

// NUEVO PRODUCTO
function nuevoProducto() {

    editando.value = false
    errorFormulario.value = ''

    formulario.value = {
        id_producto: null,
        nombre: '',
        descripcion: '',
        id_categoria: '',
        precio: ''
    }

    mostrarFormulario.value = true

}

// EDITAR PRODUCTO
function editarProducto(producto) {

    editando.value = true
    errorFormulario.value = ''

    formulario.value = {
        id_producto: producto.id_producto,
        nombre: producto.nombre,
        descripcion: producto.descripcion || '',
        id_categoria: String(producto.id_categoria),
        precio: Number(producto.precio)
    }

    mostrarFormulario.value = true

}

// CERRAR MODAL
function cerrarFormulario() {

    mostrarFormulario.value = false
    errorFormulario.value = ''

}

// GUARDAR PRODUCTO
async function guardarProducto() {

    errorFormulario.value = ''
    mensaje.value = ''

    if (!formulario.value.id_categoria) {
        errorFormulario.value = 'Selecciona una categoría.'
        return
    }

    if (Number(formulario.value.precio) <= 0) {
        errorFormulario.value = 'El precio debe ser mayor que cero.'
        return
    }

    guardando.value = true

    try {

        const respuesta = await fetch(
            API + 'productos.php',
            {
                method: 'POST',
                credentials: 'include',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify({

                    accion: editando.value ? 'editar' : 'crear',

                    id_producto: formulario.value.id_producto,

                    nombre: formulario.value.nombre,

                    descripcion: formulario.value.descripcion,

                    id_categoria: Number(formulario.value.id_categoria),

                    precio: Number(formulario.value.precio)

                })
            }
        )

        const datos = await respuesta.json()

        if (!respuesta.ok) {
            throw new Error(datos.error || 'No se pudo guardar el producto')
        }

        mensaje.value = datos.mensaje

        cerrarFormulario()

        await cargarProductos()

    } catch (e) {

        errorFormulario.value = e.message

    } finally {

        guardando.value = false

    }

}

// ACTIVAR / DESACTIVAR PRODUCTO
async function cambiarEstado(producto) {

    const nuevoEstado = !esActivo(producto.activo)

    const confirmacion = confirm(
        nuevoEstado
            ? '¿Deseas activar este producto?'
            : '¿Deseas desactivar este producto?'
    )

    if (!confirmacion) return

    error.value = ''
    mensaje.value = ''

    try {

        const respuesta = await fetch(
            API + 'productos.php',
            {
                method: 'POST',
                credentials: 'include',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify({
                    accion: 'estado',
                    id_producto: producto.id_producto
                })
            }
        )

        const datos = await respuesta.json()

        if (!respuesta.ok) {
            throw new Error(datos.error || 'No se pudo cambiar el estado')
        }

        mensaje.value = datos.mensaje

        await cargarProductos()

    } catch (e) {

        error.value = e.message

    }

}

// FORMATO DE MONEDA
function moneda(valor) {

    return new Intl.NumberFormat('es-MX', {
        style: 'currency',
        currency: 'MXN'
    }).format(Number(valor) || 0)

}

// INICIALIZAR COMPONENTE
onMounted(cargarDatos)
</script>
