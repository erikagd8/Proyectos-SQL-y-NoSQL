
<script setup>
import { ref, onMounted } from 'vue'

const API = 'http://localhost/heladeria/api/'

const pestana = ref('perfil')
const cargando = ref(false)
const mensaje = ref('')
const error = ref('')

const perfil = ref({
    nombre: '',
    apellido_paterno: '',
    apellido_materno: '',
    usuario: ''
})

const contrasenas = ref({
    password_actual: '',
    password_nueva: '',
    confirmar_password: ''
})

async function cargarPerfil() {
    cargando.value = true
    error.value = ''

    try {
        const respuesta = await fetch(API + 'perfil.php', {
            credentials: 'include'
        })

        const datos = await respuesta.json()

        if (!respuesta.ok) throw new Error(datos.error)

        perfil.value = datos.perfil

    } catch (e) {
        error.value = e.message
    } finally {
        cargando.value = false
    }
}

async function actualizarPerfil() {
    mensaje.value = ''
    error.value = ''

    try {
        const respuesta = await fetch(API + 'perfil.php', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(perfil.value)
        })

        const datos = await respuesta.json()

        if (!respuesta.ok) throw new Error(datos.error)

        mensaje.value = datos.mensaje

        await cargarPerfil()

    } catch (e) {
        error.value = e.message
    }
}

async function cambiarPassword() {
    mensaje.value = ''
    error.value = ''

    try {
        const respuesta = await fetch(API + 'cambiar_password.php', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(contrasenas.value)
        })

        const datos = await respuesta.json()

        if (!respuesta.ok) throw new Error(datos.error)

        mensaje.value = datos.mensaje

        contrasenas.value = {
            password_actual: '',
            password_nueva: '',
            confirmar_password: ''
        }

    } catch (e) {
        error.value = e.message
    }
}

onMounted(cargarPerfil)
</script>

<template>
    <section id="modulo-mi-cuenta">

        <div class="modulo-encabezado">
            <div>
                <h1>Mi cuenta</h1>
                <p>Administra tu información personal y seguridad.</p>
            </div>
        </div>

        <div class="cuenta-contenedor">

            <div class="cuenta-pestanas">
                <button
                    :class="{ 'pestana-activa': pestana === 'perfil' }"
                    @click="pestana = 'perfil'"
                >
                    Información personal
                </button>

                <button
                    :class="{ 'pestana-activa': pestana === 'seguridad' }"
                    @click="pestana = 'seguridad'"
                >
                    Seguridad
                </button>
            </div>

            <p v-if="mensaje" class="mensaje-exito">
                {{ mensaje }}
            </p>

            <p v-if="error" class="login-error">
                {{ error }}
            </p>

            <div v-if="cargando">
                Cargando información...
            </div>

            <form
                v-else-if="pestana === 'perfil'"
                class="cuenta-formulario"
                @submit.prevent="actualizarPerfil"
            >
                <h2>Información personal</h2>
                <p>Actualiza los datos de tu cuenta administrativa.</p>

                <label>Nombre</label>
                <input v-model="perfil.nombre" required>

                <label>Apellido paterno</label>
                <input v-model="perfil.apellido_paterno" required>

                <label>Apellido materno</label>
                <input v-model="perfil.apellido_materno" required>

                <label>Nombre de usuario</label>
                <input v-model="perfil.usuario" required>

                <button type="submit" class="boton-principal">
                    Guardar cambios
                </button>
            </form>

            <form
                v-else
                class="cuenta-formulario"
                @submit.prevent="cambiarPassword"
            >
                <h2>Cambiar contraseña</h2>
                <p>Utiliza una contraseña segura de al menos 8 caracteres.</p>

                <label>Contraseña actual</label>
                <input
                    v-model="contrasenas.password_actual"
                    type="password"
                    autocomplete="current-password"
                    required
                >

                <label>Nueva contraseña</label>
                <input
                    v-model="contrasenas.password_nueva"
                    type="password"
                    autocomplete="new-password"
                    minlength="8"
                    required
                >

                <label>Confirmar nueva contraseña</label>
                <input
                    v-model="contrasenas.confirmar_password"
                    type="password"
                    autocomplete="new-password"
                    minlength="8"
                    required
                >

                <button type="submit" class="boton-principal">
                    Cambiar contraseña
                </button>
            </form>

        </div>

    </section>
</template>
