
<script setup>
import { ref, computed, onMounted } from 'vue'

const API = 'http://localhost/heladeria/api/categorias.php'

const categorias = ref([])
const busqueda = ref('')

const cargando = ref(false)
const guardando = ref(false)
const procesandoEstado = ref(null)

const error = ref('')
const mensaje = ref('')

const modalAbierto = ref(false)
const modoEdicion = ref(false)

const formulario = ref({
    id_categoria: null,
    nombre: '',
    descripcion: ''
})

// =====================================
// CATEGORIAS FILTRADAS
// =====================================

const categoriasFiltradas = computed(() => {

    const texto = busqueda.value.toLowerCase().trim()

    return categorias.value.filter(c =>
        c.nombre.toLowerCase().includes(texto) ||
        (c.descripcion || '').toLowerCase().includes(texto)
    )
})

// =====================================
// ESTADISTICAS
// =====================================

const categoriasActivas = computed(() =>
    categorias.value.filter(c => c.activa === true).length
)

const categoriasInactivas = computed(() =>
    categorias.value.filter(c => c.activa === false).length
)

// =====================================
// CONSULTAR CATEGORIAS
// =====================================

async function cargarCategorias() {

    cargando.value = true
    error.value = ''

    try {

        const respuesta = await fetch(API, {
            method: 'GET',
            credentials: 'include'
        })

        const datos = await respuesta.json()

        if (!respuesta.ok) {
            throw new Error(datos.error || 'No se pudieron cargar las categorías.')
        }

        categorias.value = (datos.categorias || []).map(c => ({
            ...c,
            id_categoria: Number(c.id_categoria),
            activa: c.activa === true || c.activa === 't',
            total_productos: Number(c.total_productos)
        }))

    } catch (e) {

        error.value = e.message

    } finally {

        cargando.value = false
    }
}

// =====================================
// NUEVA CATEGORIA
// =====================================

function abrirNuevaCategoria() {

    modoEdicion.value = false

    formulario.value = {
        id_categoria: null,
        nombre: '',
        descripcion: ''
    }

    error.value = ''
    mensaje.value = ''

    modalAbierto.value = true
}

// =====================================
// EDITAR CATEGORIA
// =====================================

function editarCategoria(categoria) {

    modoEdicion.value = true

    formulario.value = {
        id_categoria: categoria.id_categoria,
        nombre: categoria.nombre,
        descripcion: categoria.descripcion || ''
    }

    error.value = ''
    mensaje.value = ''

    modalAbierto.value = true
}

// =====================================
// GUARDAR CATEGORIA
// =====================================

async function guardarCategoria() {

    error.value = ''
    mensaje.value = ''

    const nombre = formulario.value.nombre.trim()
    const descripcion = formulario.value.descripcion.trim()

    if (!nombre) {
        error.value = 'Escribe el nombre de la categoría.'
        return
    }

    guardando.value = true

    try {

        const respuesta = await fetch(API, {

            method: modoEdicion.value ? 'PUT' : 'POST',

            credentials: 'include',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                id_categoria: formulario.value.id_categoria,
                nombre,
                descripcion
            })

        })

        const datos = await respuesta.json()

        if (!respuesta.ok) {
            throw new Error(datos.error || 'No se pudo guardar la categoría.')
        }

        modalAbierto.value = false

        mensaje.value = datos.mensaje

        await cargarCategorias()

    } catch (e) {

        error.value = e.message

    } finally {

        guardando.value = false
    }
}

// =====================================
// ACTIVAR O DESACTIVAR
// =====================================

async function cambiarEstado(categoria) {

    if (procesandoEstado.value !== null) return

    const nuevoEstado = !categoria.activa

    const accion = nuevoEstado ? 'activar' : 'desactivar'

    const confirmacion = window.confirm(
        `¿Deseas ${accion} la categoría "${categoria.nombre}"?`
    )

    if (!confirmacion) return

    error.value = ''
    mensaje.value = ''

    procesandoEstado.value = categoria.id_categoria

    try {

        const respuesta = await fetch(API, {

            method: 'PATCH',

            credentials: 'include',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                id_categoria: Number(categoria.id_categoria),
                activa: nuevoEstado
            })

        })

        const datos = await respuesta.json()

        if (!respuesta.ok) {
            throw new Error(datos.error || 'No se pudo cambiar el estado.')
        }

        // Actualizar inmediatamente la vista
        const indice = categorias.value.findIndex(
            c => Number(c.id_categoria) === Number(categoria.id_categoria)
        )

        if (indice !== -1) {
            categorias.value[indice].activa = nuevoEstado
        }

        mensaje.value = datos.mensaje

        // Comprobar el estado real en PostgreSQL
        await cargarCategorias()

    } catch (e) {

        error.value = e.message

    } finally {

        procesandoEstado.value = null
    }
}

// =====================================
// INICIALIZAR
// =====================================

onMounted(cargarCategorias)
</script>

<template>
    <section id="modulo-categorias">

        <!-- ENCABEZADO -->

        <div class="modulo-encabezado">

            <div>
                <h1>Gestión de categorías</h1>

                <p>
                    Organiza y administra los productos de tu heladería.
                </p>
            </div>

            <button
                class="boton-principal"
                @click="abrirNuevaCategoria"
            >
                + Nueva categoría
            </button>

        </div>

        <!-- MENSAJES -->

        <p v-if="mensaje" class="mensaje-exito">
            {{ mensaje }}
        </p>

        <p v-if="error && !modalAbierto" class="login-error">
            {{ error }}
        </p>

        <!-- BUSCADOR -->

        <div class="categorias-busqueda">

            <input
                v-model="busqueda"
                type="search"
                placeholder="Buscar categoría..."
            >


        </div>

        <!-- TABLA -->

        <div class="tabla-contenedor">

            <table>

                <thead>

                    <tr>
                        <th>Categoría</th>
                        <th>Descripción</th>
                        <th>Productos</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>

                </thead>

                <tbody>

                    <tr v-if="cargando">

                        <td colspan="5">
                            Cargando categorías...
                        </td>

                    </tr>

                    <tr v-else-if="categoriasFiltradas.length === 0">

                        <td colspan="5">
                            No se encontraron categorías.
                        </td>

                    </tr>

                    <tr
                        v-for="categoria in categoriasFiltradas"
                        :key="categoria.id_categoria"
                    >

                        <td>
                            <strong>{{ categoria.nombre }}</strong>
                        </td>

                        <td>
                            {{ categoria.descripcion || 'Sin descripción' }}
                        </td>

                        <td>
                            {{ categoria.total_productos }}
                        </td>

                        <td>

                            <span
                                :class="categoria.activa
                                    ? 'estado-activo'
                                    : 'estado-inactivo'"
                            >
                                {{ categoria.activa ? 'Activa' : 'Inactiva' }}
                            </span>

                        </td>

                        <td>

                            <div class="categorias-acciones">

                                <button
                                    type="button"
                                    class="boton-tabla"
                                    @click="editarCategoria(categoria)"
                                    title="Editar categoría"
                                >
                                    ✎
                                </button>

                                <button
                                    type="button"
                                    class="boton-tabla"
                                    @click="cambiarEstado(categoria)"
                                    :disabled="procesandoEstado === categoria.id_categoria"
                                    :title="categoria.activa ? 'Desactivar' : 'Activar'"
                                >
                                    {{
                                        procesandoEstado === categoria.id_categoria
                                            ? '...'
                                            : categoria.activa ? '⊘' : '✓'
                                    }}
                                </button>

                            </div>

                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

        <!-- MODAL -->

        <div
            v-if="modalAbierto"
            class="modal-fondo"
            @click.self="modalAbierto = false"
        >

            <form
                class="modal-contenido"
                @submit.prevent="guardarCategoria"
            >

                <h2>
                    {{ modoEdicion ? 'Editar categoría' : 'Nueva categoría' }}
                </h2>

                <p>
                    Completa los datos de la categoría.
                </p>

                <label for="nombre-categoria">
                    Nombre de la categoría
                </label>

                <input
                    id="nombre-categoria"
                    v-model="formulario.nombre"
                    type="text"
                    maxlength="50"
                    placeholder="Ej. Malteadas"
                    required
                >

                <label for="descripcion-categoria">
                    Descripción
                </label>

                <textarea
                    id="descripcion-categoria"
                    v-model="formulario.descripcion"
                    maxlength="150"
                    rows="3"
                    placeholder="Describe brevemente la categoría..."
                ></textarea>

                <p v-if="error" class="login-error">
                    {{ error }}
                </p>

                <div class="modal-acciones">

                    <button
                        type="button"
                        class="boton-secundario"
                        @click="modalAbierto = false"
                    >
                        Cancelar
                    </button>

                    <button
                        type="submit"
                        class="boton-principal"
                        :disabled="guardando"
                    >
                        {{
                            guardando
                                ? 'Guardando...'
                                : modoEdicion
                                    ? 'Guardar cambios'
                                    : 'Registrar categoría'
                        }}
                    </button>

                </div>

            </form>

        </div>

    </section>
</template>
