
<script setup>
import { ref } from 'vue'

const usuario = ref('')
const password = ref('')
const cargando = ref(false)
const error = ref('')

const emit = defineEmits(['authenticated'])

async function iniciarSesion() {
    error.value = ''
    cargando.value = true

    try {
        const respuesta = await fetch(
            'http://localhost/heladeria/api/login.php',
            {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    usuario: usuario.value,
                    password: password.value
                })
            }
        )

        const datos = await respuesta.json()

        if (!respuesta.ok) {
            throw new Error(datos.error || 'No se pudo iniciar sesión')
        }

        emit('authenticated', datos.usuario)

    } catch (e) {
        error.value = e.message

    } finally {
        cargando.value = false
    }
}
</script>

<template>
    <main class="login-page">

        <section class="login-card">

            <div class="login-logo">
                <span>UPA</span>
            </div>

            <h1>Heladeria</h1>
            <p class="login-subtitle">
                Sistema de gestión de heladería
            </p>

            <div class="login-separator"></div>

            <h2>Bienvenido</h2>
            <p class="login-description">
                Ingresa tus credenciales para continuar.
            </p>

            <form @submit.prevent="iniciarSesion">

                <label for="usuario">Usuario</label>

                <input
                    id="usuario"
                    v-model="usuario"
                    type="text"
                    placeholder="Ingresa tu usuario"
                    autocomplete="username"
                    required
                >

                <label for="password">Contraseña</label>

                <input
                    id="password"
                    v-model="password"
                    type="password"
                    placeholder="Ingresa tu contraseña"
                    autocomplete="current-password"
                    required
                >

                <p v-if="error" class="login-error">
                    {{ error }}
                </p>

                <button type="submit" :disabled="cargando">
                    {{ cargando ? 'Verificando...' : 'Iniciar sesión' }}
                </button>

            </form>

            <p class="login-footer">
                Acceso exclusivo para administradores
            </p>

        </section>

    </main>
</template>
