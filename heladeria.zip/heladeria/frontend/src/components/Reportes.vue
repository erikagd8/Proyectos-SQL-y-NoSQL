
<script setup>
import { ref, onMounted } from 'vue'

const reporte = ref(null)
const error = ref('')
const cargando = ref(false)

async function cargarReportes() {
    cargando.value = true

    try {
        const r = await fetch('http://localhost/heladeria/api/reportes.php', {
            credentials: 'include'
        })

        const d = await r.json()

        if (!r.ok) throw new Error(d.error)

        reporte.value = d

    } catch (e) {
        error.value = e.message
    } finally {
        cargando.value = false
    }
}

function moneda(valor) {
    return new Intl.NumberFormat('es-MX', {
        style: 'currency',
        currency: 'MXN'
    }).format(valor)
}

onMounted(cargarReportes)
</script>

<template>
    <section id="modulo-reportes">

        <div class="modulo-encabezado">
            <div>
                <h1>Reportes del negocio</h1>
                <p>Resumen de los resultados de Dulce Frío.</p>
            </div>

            <button class="boton-secundario" @click="cargarReportes">
                Actualizar
            </button>
        </div>

        <p v-if="error" class="login-error">{{ error }}</p>

        <div v-if="reporte" class="estadisticas-dashboard">

            <article class="estadistica-card">
                <span>Ventas totales</span>
                <strong>{{ reporte.general.total_ventas }}</strong>
            </article>

            <article class="estadistica-card">
                <span>Ingresos acumulados</span>
                <strong>{{ moneda(reporte.general.ingresos) }}</strong>
            </article>

            <article class="estadistica-card">
                <span>Promedio por venta</span>
                <strong>{{ moneda(reporte.general.promedio) }}</strong>
            </article>

        </div>

        <div v-if="reporte" class="reporte-columnas">

            <article class="reporte-panel">
                <h2>Ventas de los últimos siete días</h2>

                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Ventas</th>
                            <th>Ingresos</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr v-for="d in reporte.diario" :key="d.dia">
                            <td>{{ d.dia }}</td>
                            <td>{{ d.ventas }}</td>
                            <td>{{ moneda(d.ingresos) }}</td>
                        </tr>
                    </tbody>
                </table>
            </article>

            <article class="reporte-panel">
                <h2>Productos más vendidos</h2>

                <table>
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Unidades</th>
                            <th>Ingresos</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr v-for="p in reporte.populares" :key="p.nombre">
                            <td>{{ p.nombre }}</td>
                            <td>{{ p.unidades }}</td>
                            <td>{{ moneda(p.ingresos) }}</td>
                        </tr>

                        <tr v-if="!reporte.populares.length">
                            <td colspan="3">Todavía no hay productos vendidos.</td>
                        </tr>
                    </tbody>
                </table>
            </article>

        </div>

    </section>
</template>
