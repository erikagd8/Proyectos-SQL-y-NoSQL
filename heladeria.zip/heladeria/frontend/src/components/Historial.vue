
<script setup>
import { ref, onMounted } from 'vue'

const ventas = ref([])
const cargando = ref(false)
const error = ref('')
const busqueda = ref('')

async function cargarHistorial() {
    cargando.value = true

    try {
        const r = await fetch('http://localhost/heladeria/api/historial.php', {
            credentials: 'include'
        })

        const d = await r.json()

        if (!r.ok) throw new Error(d.error)

        ventas.value = d.ventas

    } catch (e) {
        error.value = e.message
    } finally {
        cargando.value = false
    }
}

function moneda(valor) {
    return new Intl.NumberFormat('es-MX', {
        style: 'currency',
        currency: 'MXN'
    }).format(valor)
}

function fecha(valor) {
    return new Date(valor).toLocaleString('es-MX')
}

onMounted(cargarHistorial)
</script>

<template>
    <section id="modulo-historial">

        <div class="modulo-encabezado">
            <div>
                <h1>Historial de ventas</h1>
                <p>Consulta las operaciones realizadas.</p>
            </div>
        </div>

        <input
            v-model="busqueda"
            class="busqueda-historial"
            placeholder="Buscar por número de venta..."
        >

        <p v-if="error" class="login-error">{{ error }}</p>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>Venta</th>
                        <th>Fecha</th>
                        <th>Productos</th>
                        <th>Unidades</th>
                        <th>Pago</th>
                        <th>Total</th>
                    </tr>
                </thead>

                <tbody>
                    <tr
                        v-for="v in ventas.filter(x => String(x.id_venta).includes(busqueda))"
                        :key="v.id_venta"
                    >
                        <td>#{{ v.id_venta }}</td>
                        <td>{{ fecha(v.fecha) }}</td>
                        <td>{{ v.productos || 'Sin detalles' }}</td>
                        <td>{{ v.unidades }}</td>
                        <td>{{ v.metodo_pago }}</td>
                        <td><strong>{{ moneda(v.total) }}</strong></td>
                    </tr>

                    <tr v-if="!ventas.length && !cargando">
                        <td colspan="6">Todavía no hay ventas registradas.</td>
                    </tr>
                </tbody>
            </table>
        </div>

    </section>
</template>
