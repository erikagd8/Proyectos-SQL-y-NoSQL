
<template>
    <div v-if="cargando" class="pantalla-carga">
        <div class="login-logo">H</div>
        <p>Iniciando...</p>
    </div>

    <Login
        v-else-if="!autenticado"
        @authenticated="acceder"
    />

    <div v-else id="dashboard" class="estructura-dashboard">

        <div
            v-if="menuMovilAbierto"
            class="fondo-menu"
            @click="menuMovilAbierto = false"
        ></div>

        <Sidebar
            :colapsado="sidebarColapsado"
            :seccion-activa="seccionActiva"
            :class="{ 'sidebar-abierto': menuMovilAbierto }"
            @alternar="alternarMenu"
            @navegar="navegar"
            @cerrar-sesion="cerrarSesion"
        />

        <main
            id="contenido-principal"
            class="contenido-principal"
            :class="{ 'contenido-expandido': sidebarColapsado }"
        >

            <!-- BARRA SUPERIOR -->
            <header id="barra-superior" class="barra-superior">

                <button
                    class="boton-hamburguesa"
                    @click="alternarMenu"
                    aria-label="Abrir o cerrar menú"
                >
                    ☰
                </button>

                <strong>{{ titulos[seccionActiva] }}</strong>

                <div class="barra-usuario">

                    <span class="usuario-avatar">
                        {{ usuario?.nombre?.charAt(0) || 'A' }}
                    </span>

                    <span>
                        {{ usuario?.nombre }}
                        {{ usuario?.apellido_paterno }}
                        {{ usuario?.apellido_materno }}
                    </span>

                </div>

            </header>

            <!-- CONTENIDO PRINCIPAL -->
            <section id="contenido-seccion" class="contenido-seccion">

                <!-- INICIO -->
                <template v-if="seccionActiva === 'inicio'">

                    <div
                        id="bienvenida-dashboard"
                        class="bienvenida-dashboard"
                    >

                        <span class="dashboard-etiqueta">
                            ADMINISTRACIÓN
                        </span>

                        <h1>
                            Bienvenido,
                            {{ usuario?.nombre }}
                            {{ usuario?.apellido_paterno }}
                            {{ usuario?.apellido_materno }}
                        </h1>

                        <p>
                            Administra las operaciones de tu heladería
                            desde un solo lugar.
                        </p>

                    </div>

                    <!-- ESTADÍSTICAS -->
                    <section
                        id="estadisticas-dashboard"
                        class="estadisticas-dashboard"
                    >

                        <article class="estadistica-card">
                            <span>Productos activos</span>
                            <strong>{{ resumen.productos }}</strong>
                            <small>Productos registrados</small>
                        </article>

                        <article class="estadistica-card">
                            <span>Ventas realizadas</span>
                            <strong>{{ resumen.ventas }}</strong>
                            <small>Operaciones acumuladas</small>
                        </article>

                        <article class="estadistica-card">
                            <span>Ingresos totales</span>
                            <strong>{{ moneda(resumen.ingresos) }}</strong>
                            <small>Ingresos acumulados</small>
                        </article>

                        <article class="estadistica-card">
                            <span>Ventas de hoy</span>
                            <strong>{{ resumen.ventas_hoy }}</strong>
                            <small>{{ moneda(resumen.ingresos_hoy) }}</small>
                        </article>

                    </section>

                    <!-- ACCESOS DIRECTOS -->
                    <div
                        id="tarjetas-dashboard"
                        class="dashboard-grid"
                    >

                        <article class="dashboard-card">

                            <span class="tarjeta-icono">▦</span>
                            <span>Productos</span>

                            <h3>Gestión de productos</h3>

                            <p>
                                Consulta y administra tu catálogo.
                            </p>

                            <button @click="navegar('productos')">
                                Ir a productos →
                            </button>

                        </article>

                        <article class="dashboard-card">

                            <span class="tarjeta-icono">＋</span>
                            <span>Ventas</span>

                            <h3>Registrar ventas</h3>

                            <p>
                                Registra las compras de tus clientes.
                            </p>

                            <button @click="navegar('ventas')">
                                Nueva venta →
                            </button>

                        </article>

                        <article class="dashboard-card">

                            <span class="tarjeta-icono">▤</span>
                            <span>Historial</span>

                            <h3>Historial de ventas</h3>

                            <p>
                                Consulta las operaciones realizadas.
                            </p>

                            <button @click="navegar('historial')">
                                Consultar historial →
                            </button>

                        </article>

                        <article class="dashboard-card">

                            <span class="tarjeta-icono">▦</span>
                            <span>Categorías</span>

                            <h3>Gestión de categorías</h3>

                            <p>
                                Organiza los productos de tu heladería.
                            </p>

                            <button @click="navegar('categorias')">
                                Administrar categorías →
                            </button>

                        </article>

                    </div>

                </template>

                <!-- MÓDULOS -->
                <Productos
                    v-else-if="seccionActiva === 'productos'"
                />

                <Categorias
                    v-else-if="seccionActiva === 'categorias'"
                />

                <Ventas
                    v-else-if="seccionActiva === 'ventas'"
                />

                <Historial
                    v-else-if="seccionActiva === 'historial'"
                />

                <MiCuenta
                    v-else-if="seccionActiva === 'cuenta'"
                />

            </section>

            <!-- ERRORES GENERALES -->
            <p v-if="error" class="error-general">
                {{ error }}
            </p>

        </main>

    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

import Login from './components/Login.vue'
import Sidebar from './components/Sidebar.vue'
import Productos from './components/Productos.vue'
import Categorias from './components/Categorias.vue'
import Ventas from './components/Ventas.vue'
import Historial from './components/Historial.vue'
import MiCuenta from './components/MiCuenta.vue'

const API = 'http://localhost/heladeria/api/'

const autenticado = ref(false)
const usuario = ref(null)
const cargando = ref(true)
const error = ref('')

const sidebarColapsado = ref(false)
const menuMovilAbierto = ref(false)
const seccionActiva = ref('inicio')

const resumen = ref({
    productos: 0,
    ventas: 0,
    ingresos: 0,
    ventas_hoy: 0,
    ingresos_hoy: 0
})

// TÍTULOS DE LOS MÓDULOS
const titulos = {
    inicio: 'Panel de control',
    productos: 'Gestión de productos',
    categorias: 'Gestión de categorías',
    ventas: 'Registrar ventas',
    historial: 'Historial de ventas',
    cuenta: 'Mi cuenta'
}

// OBTENER RESUMEN
async function obtenerResumen() {

    const r = await fetch(API + 'resumen.php', {
        credentials: 'include'
    })

    const d = await r.json()

    if (!r.ok) {
        throw new Error(d.error || 'Error al obtener el resumen')
    }

    resumen.value = d
}

// VERIFICAR SESIÓN
async function verificarSesion() {

    try {

        const r = await fetch(
            API + 'verificar_sesion.php',
            {
                credentials: 'include'
            }
        )

        const d = await r.json()

        autenticado.value = d.autenticado
        usuario.value = d.usuario

        if (autenticado.value) {
            await obtenerResumen()
        }

    } catch (e) {

        error.value = e.message

    } finally {

        cargando.value = false

    }
}

// ACCEDER DESPUÉS DEL LOGIN
async function acceder() {

    try {

        const respuesta = await fetch(
            API + 'verificar_sesion.php',
            {
                credentials: 'include'
            }
        )

        const datos = await respuesta.json()

        if (!respuesta.ok || !datos.autenticado) {
            throw new Error('No se pudo recuperar la sesión')
        }

        usuario.value = datos.usuario
        autenticado.value = true
        seccionActiva.value = 'inicio'
        error.value = ''

        await obtenerResumen()

    } catch (e) {

        autenticado.value = false
        usuario.value = null
        error.value = e.message

    }

}

// NAVEGACIÓN
function navegar(seccion) {

    if (!titulos[seccion]) return

    seccionActiva.value = seccion
    menuMovilAbierto.value = false

    if (seccion === 'inicio') {
        obtenerResumen().catch(e => {
            error.value = e.message
        })
    }

}

// ALTERNAR MENÚ
function alternarMenu() {

    if (window.innerWidth <= 768) {

        menuMovilAbierto.value = !menuMovilAbierto.value

    } else {

        sidebarColapsado.value = !sidebarColapsado.value

    }

}

// CERRAR SESIÓN
async function cerrarSesion() {

    try {

        const r = await fetch(
            API + 'cerrar_sesion.php',
            {
                method: 'POST',
                credentials: 'include'
            }
        )

        if (!r.ok) {
            throw new Error('No se pudo cerrar la sesión')
        }

        autenticado.value = false
        usuario.value = null
        seccionActiva.value = 'inicio'
        error.value = ''

    } catch (e) {

        error.value = e.message

    }

}

// FORMATO DE MONEDA
function moneda(valor) {

    return new Intl.NumberFormat('es-MX', {
        style: 'currency',
        currency: 'MXN'
    }).format(Number(valor) || 0)

}

// INICIALIZAR
onMounted(verificarSesion)
</script>
