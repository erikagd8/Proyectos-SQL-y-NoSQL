
<?php

return [
    "correo" => "eri@gmail.com",
    
    "password" => "sysp eqek sett swgi",

    "nombre" => "Dulce Frío",

    "url_frontend" => "http://localhost:5173"
];

