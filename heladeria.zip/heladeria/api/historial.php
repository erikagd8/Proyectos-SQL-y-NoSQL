
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

try {

    $sql = "
        SELECT
            v.id_venta,
            v.fecha,
            v.total,
            v.metodo_pago,
            COALESCE(SUM(d.cantidad), 0) AS unidades,
            STRING_AGG(
                p.nombre || ' x' || d.cantidad,
                ', ' ORDER BY p.nombre
            ) AS productos
        FROM ventas v
        LEFT JOIN detalle_venta d ON d.id_venta = v.id_venta
        LEFT JOIN productos p ON p.id_producto = d.id_producto
        GROUP BY v.id_venta
        ORDER BY v.fecha DESC
    ";

    $stmt = $conexion->query($sql);

    responder([
        "success" => true,
        "ventas" => $stmt->fetchAll()
    ]);

} catch (PDOException $e) {
    responder(["error" => "No se pudo consultar el historial"], 500);
}
