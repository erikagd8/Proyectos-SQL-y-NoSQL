
<?php

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Vary: Origin");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

session_set_cookie_params([
    "lifetime" => 0,
    "path" => "/",
    "secure" => false,
    "httponly" => true,
    "samesite" => "Lax"
]);

session_start();

require_once __DIR__ . "/../conexion.php";

function responder($datos, $codigo = 200) {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

function exigirSesion() {
    if (empty($_SESSION["usuario_id"])) {
        responder([
            "success" => false,
            "error" => "Sesión no autorizada"
        ], 401);
    }
}

function obtenerJSON() {
    $datos = json_decode(file_get_contents("php://input"), true);

    if (!is_array($datos)) {
        responder([
            "success" => false,
            "error" => "Solicitud inválida"
        ], 400);
    }

    return $datos;
}
