
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

try {

    $productos = $conexion->query("
        SELECT COUNT(*) FROM productos WHERE activo = TRUE
    ")->fetchColumn();

    $ventas = $conexion->query("
        SELECT COUNT(*) FROM ventas
    ")->fetchColumn();

    $ingresos = $conexion->query("
        SELECT COALESCE(SUM(total), 0) FROM ventas
    ")->fetchColumn();

    $hoy = $conexion->query("
        SELECT COUNT(*) AS cantidad,
               COALESCE(SUM(total), 0) AS ingresos
        FROM ventas
        WHERE fecha::date = CURRENT_DATE
    ")->fetch();

    responder([
        "success" => true,
        "productos" => (int)$productos,
        "ventas" => (int)$ventas,
        "ingresos" => (float)$ingresos,
        "ventas_hoy" => (int)$hoy["cantidad"],
        "ingresos_hoy" => (float)$hoy["ingresos"]
    ]);

} catch (PDOException $e) {
    responder(["error" => "Error al consultar el resumen"], 500);
}
