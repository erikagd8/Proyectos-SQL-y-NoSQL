
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

try {

    $general = $conexion->query("
        SELECT
            COUNT(*) AS total_ventas,
            COALESCE(SUM(total), 0) AS ingresos,
            COALESCE(AVG(total), 0) AS promedio
        FROM ventas
    ")->fetch();

    $diario = $conexion->query("
        SELECT
            fecha::date AS dia,
            COUNT(*) AS ventas,
            SUM(total) AS ingresos
        FROM ventas
        GROUP BY fecha::date
        ORDER BY dia DESC
        LIMIT 7
    ")->fetchAll();

    $populares = $conexion->query("
        SELECT
            p.nombre,
            SUM(d.cantidad) AS unidades,
            SUM(d.subtotal) AS ingresos
        FROM detalle_venta d
        INNER JOIN productos p
            ON p.id_producto = d.id_producto
        GROUP BY p.id_producto, p.nombre
        ORDER BY unidades DESC
        LIMIT 5
    ")->fetchAll();

    responder([
        "success" => true,
        "general" => $general,
        "diario" => $diario,
        "populares" => $populares
    ]);

} catch (PDOException $e) {
    responder(["error" => "No se pudieron generar los reportes"], 500);
}
