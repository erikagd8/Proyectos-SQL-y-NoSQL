
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    try {
        $consulta = $conexion->prepare("
            SELECT id_usuario, nombre, apellido_paterno,
                   apellido_materno, usuario
            FROM usuarios
            WHERE id_usuario = :id AND activo = TRUE
        ");

        $consulta->execute([
            ":id" => $_SESSION["usuario_id"]
        ]);

        $perfil = $consulta->fetch();

        if (!$perfil) {
            responder(["error" => "Administrador no encontrado"], 404);
        }

        responder([
            "success" => true,
            "perfil" => $perfil
        ]);

    } catch (PDOException $e) {
        responder(["error" => "No se pudo consultar el perfil"], 500);
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $datos = obtenerJSON();

    $nombre = trim($datos["nombre"] ?? "");
    $paterno = trim($datos["apellido_paterno"] ?? "");
    $materno = trim($datos["apellido_materno"] ?? "");
    $usuario = trim($datos["usuario"] ?? "");

    if (!$nombre || !$paterno || !$materno || !$usuario) {
        responder(["error" => "Completa todos los campos"], 400);
    }

    try {
        $consulta = $conexion->prepare("
            UPDATE usuarios
            SET nombre = :nombre,
                apellido_paterno = :paterno,
                apellido_materno = :materno,
                usuario = :usuario
            WHERE id_usuario = :id AND activo = TRUE
        ");

        $consulta->execute([
            ":nombre" => $nombre,
            ":paterno" => $paterno,
            ":materno" => $materno,
            ":usuario" => $usuario,
            ":id" => $_SESSION["usuario_id"]
        ]);

        responder([
            "success" => true,
            "mensaje" => "Información actualizada correctamente"
        ]);

    } catch (PDOException $e) {
        if ($e->getCode() === "23505") {
            responder(["error" => "Ese nombre de usuario ya existe"], 409);
        }

        responder(["error" => "No se pudo actualizar la información"], 500);
    }
}

responder(["error" => "Método no permitido"], 405);
