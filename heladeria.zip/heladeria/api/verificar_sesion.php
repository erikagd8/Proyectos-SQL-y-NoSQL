
<?php

require_once __DIR__ . "/seguridad.php";

// Comprobar que exista una sesión iniciada
if (empty($_SESSION["usuario_id"])) {
    responder([
        "autenticado" => false,
        "usuario" => null
    ], 401);
}

try {

    // Consultar los datos actuales del administrador
    $consulta = $conexion->prepare("
        SELECT
            id_usuario,
            nombre,
            apellido_paterno,
            apellido_materno,
            usuario
        FROM usuarios
        WHERE id_usuario = :id
        AND activo = TRUE
    ");

    $consulta->execute([
        ":id" => $_SESSION["usuario_id"]
    ]);

    $administrador = $consulta->fetch();

    // Si el administrador ya no existe o está inactivo
    if (!$administrador) {
        $_SESSION = [];
        session_destroy();

        responder([
            "autenticado" => false,
            "usuario" => null,
            "error" => "La cuenta no está disponible."
        ], 401);
    }

    // Devolver los datos actualizados desde PostgreSQL
    responder([
        "autenticado" => true,
        "usuario" => [
            "id" => $administrador["id_usuario"],
            "nombre" => $administrador["nombre"],
            "apellido_paterno" => $administrador["apellido_paterno"],
            "apellido_materno" => $administrador["apellido_materno"],
            "usuario" => $administrador["usuario"]
        ]
    ]);

} catch (PDOException $e) {

    responder([
        "autenticado" => false,
        "error" => "No fue posible consultar los datos del administrador."
    ], 500);

}
