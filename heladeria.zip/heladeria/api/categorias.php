
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

$metodo = $_SERVER["REQUEST_METHOD"];

try {

    // CONSULTAR CATEGORÍAS
    if ($metodo === "GET") {

        $sql = "
            SELECT
                c.id_categoria,
                c.nombre,
                c.descripcion,
                c.activa,
                c.creado_en,
                COUNT(p.id_producto)::INTEGER AS total_productos
            FROM categorias c
            LEFT JOIN productos p
                ON p.id_categoria = c.id_categoria
            GROUP BY c.id_categoria
            ORDER BY c.nombre ASC
        ";

        $stmt = $conexion->query($sql);

        responder([
            "success" => true,
            "categorias" => $stmt->fetchAll()
        ]);
    }

    // REGISTRAR CATEGORÍA
    if ($metodo === "POST") {

        $datos = obtenerJSON();

        $nombre = trim($datos["nombre"] ?? "");
        $descripcion = trim($datos["descripcion"] ?? "");

        if ($nombre === "") {
            responder(["error" => "El nombre es obligatorio."], 400);
        }

        if (mb_strlen($nombre) > 50 ||
            mb_strlen($descripcion) > 150) {
            responder(["error" => "Los datos exceden el límite permitido."], 400);
        }

        $stmt = $conexion->prepare("
            INSERT INTO categorias (nombre, descripcion)
            VALUES (:nombre, :descripcion)
            RETURNING id_categoria
        ");

        $stmt->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion ?: null
        ]);

        responder([
            "success" => true,
            "mensaje" => "Categoría registrada correctamente.",
            "id_categoria" => $stmt->fetchColumn()
        ], 201);
    }

    // EDITAR CATEGORÍA
    if ($metodo === "PUT") {

        $datos = obtenerJSON();

        $id = filter_var(
            $datos["id_categoria"] ?? null,
            FILTER_VALIDATE_INT
        );

        $nombre = trim($datos["nombre"] ?? "");
        $descripcion = trim($datos["descripcion"] ?? "");

        if (!$id || $nombre === "") {
            responder(["error" => "Datos inválidos."], 400);
        }

        if (mb_strlen($nombre) > 50 ||
            mb_strlen($descripcion) > 150) {
            responder(["error" => "Los datos exceden el límite permitido."], 400);
        }

        $stmt = $conexion->prepare("
            UPDATE categorias
            SET nombre = :nombre,
                descripcion = :descripcion
            WHERE id_categoria = :id
        ");

        $stmt->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion ?: null,
            ":id" => $id
        ]);

        if ($stmt->rowCount() === 0) {
            $check = $conexion->prepare("
                SELECT 1 FROM categorias WHERE id_categoria = :id
            ");
            $check->execute([":id" => $id]);

            if (!$check->fetchColumn()) {
                responder(["error" => "Categoría no encontrada."], 404);
            }
        }

        responder([
            "success" => true,
            "mensaje" => "Categoría actualizada correctamente."
        ]);
    }

    // ACTIVAR / DESACTIVAR
    if ($metodo === "PATCH") {

        $datos = obtenerJSON();

        $id = filter_var(
            $datos["id_categoria"] ?? null,
            FILTER_VALIDATE_INT
        );

        if (!$id || !isset($datos["activa"]) ||
            !is_bool($datos["activa"])) {
            responder(["error" => "Datos de estado inválidos."], 400);
        }

        $stmt = $conexion->prepare("
            UPDATE categorias
            SET activa = :activa
            WHERE id_categoria = :id
        ");

        $stmt->bindValue(":activa", $datos["activa"], PDO::PARAM_BOOL);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        if ($stmt->rowCount() === 0) {
            $check = $conexion->prepare("
                SELECT 1 FROM categorias WHERE id_categoria = :id
            ");
            $check->execute([":id" => $id]);

            if (!$check->fetchColumn()) {
                responder(["error" => "Categoría no encontrada."], 404);
            }
        }

        responder([
            "success" => true,
            "mensaje" => "Estado actualizado correctamente."
        ]);
    }

    responder(["error" => "Método no permitido."], 405);

} catch (PDOException $e) {

    error_log("Error categorias.php: " . $e->getMessage());

    if ($e->getCode() === "23505") {
        responder(["error" => "Ya existe una categoría con ese nombre."], 409);
    }

    responder([
        "error" => "Error al procesar las categorías."
    ], 500);
}
