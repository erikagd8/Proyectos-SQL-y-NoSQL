
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(["error" => "Método no permitido"], 405);
}

$datos = obtenerJSON();

$productos = $datos["productos"] ?? [];
$metodo = $datos["metodo_pago"] ?? "";

$metodosPermitidos = ["Efectivo", "Tarjeta", "Transferencia"];

if (!is_array($productos) || count($productos) === 0) {
    responder(["error" => "Agrega productos a la venta"], 400);
}

if (!in_array($metodo, $metodosPermitidos, true)) {
    responder(["error" => "Método de pago inválido"], 400);
}

try {

    $conexion->beginTransaction();

    $total = 0;
    $detalles = [];

    foreach ($productos as $item) {

        $id = (int)($item["id_producto"] ?? 0);
        $cantidad = (int)($item["cantidad"] ?? 0);

        if ($id <= 0 || $cantidad <= 0) {
            throw new Exception("Producto o cantidad inválida");
        }

        $stmt = $conexion->prepare(
            "SELECT id_producto, nombre, precio
             FROM productos
             WHERE id_producto = :id AND activo = TRUE
             FOR UPDATE"
        );

        $stmt->execute(["id" => $id]);
        $producto = $stmt->fetch();

        if (!$producto) {
            throw new Exception("Un producto ya no está disponible");
        }

        $precio = (float)$producto["precio"];
        $subtotal = round($precio * $cantidad, 2);

        $total += $subtotal;

        $detalles[] = [
            "id_producto" => $id,
            "cantidad" => $cantidad,
            "precio" => $precio,
            "subtotal" => $subtotal
        ];
    }

    $stmt = $conexion->prepare(
        "INSERT INTO ventas (fecha, total, metodo_pago)
         VALUES (CURRENT_TIMESTAMP, :total, :metodo)
         RETURNING id_venta"
    );

    $stmt->execute([
        "total" => $total,
        "metodo" => $metodo
    ]);

    $idVenta = $stmt->fetchColumn();

    $stmtDetalle = $conexion->prepare(
        "INSERT INTO detalle_venta
         (id_venta, id_producto, cantidad, precio_unitario, subtotal)
         VALUES (:venta, :producto, :cantidad, :precio, :subtotal)"
    );

    foreach ($detalles as $detalle) {

        $stmtDetalle->execute([
            "venta" => $idVenta,
            "producto" => $detalle["id_producto"],
            "cantidad" => $detalle["cantidad"],
            "precio" => $detalle["precio"],
            "subtotal" => $detalle["subtotal"]
        ]);
    }

    $conexion->commit();

    responder([
        "success" => true,
        "id_venta" => $idVenta,
        "total" => $total,
        "mensaje" => "Venta registrada correctamente"
    ]);

} catch (Throwable $e) {

    if ($conexion->inTransaction()) {
        $conexion->rollBack();
    }

    responder([
        "error" => $e instanceof PDOException
            ? "No se pudo guardar la venta. Verifica la estructura de las tablas."
            : $e->getMessage()
    ], 400);
}
