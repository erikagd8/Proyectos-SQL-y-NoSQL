
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(["error" => "Método no permitido"], 405);
}

$datos = obtenerJSON();

$actual = $datos["password_actual"] ?? "";
$nueva = $datos["password_nueva"] ?? "";
$confirmacion = $datos["confirmar_password"] ?? "";

if (!$actual || !$nueva || !$confirmacion) {
    responder(["error" => "Completa todos los campos"], 400);
}

if (strlen($nueva) < 8) {
    responder(["error" => "La nueva contraseña debe tener al menos 8 caracteres"], 400);
}

if ($nueva !== $confirmacion) {
    responder(["error" => "Las contraseñas nuevas no coinciden"], 400);
}

try {
    $consulta = $conexion->prepare("
        SELECT password_hash
        FROM usuarios
        WHERE id_usuario = :id AND activo = TRUE
    ");

    $consulta->execute([
        ":id" => $_SESSION["usuario_id"]
    ]);

    $administrador = $consulta->fetch();

    if (!$administrador ||
        !password_verify($actual, $administrador["password_hash"])) {
        responder(["error" => "La contraseña actual es incorrecta"], 401);
    }

    $hash = password_hash($nueva, PASSWORD_DEFAULT);

    $actualizar = $conexion->prepare("
        UPDATE usuarios
        SET password_hash = :hash
        WHERE id_usuario = :id
    ");

    $actualizar->execute([
        ":hash" => $hash,
        ":id" => $_SESSION["usuario_id"]
    ]);

    responder([
        "success" => true,
        "mensaje" => "Contraseña actualizada correctamente"
    ]);

} catch (PDOException $e) {
    responder(["error" => "No se pudo cambiar la contraseña"], 500);
}
