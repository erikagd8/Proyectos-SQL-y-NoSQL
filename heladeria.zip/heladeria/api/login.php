
<?php

require_once __DIR__ . "/seguridad.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(["error" => "Método no permitido"], 405);
}

$datos = obtenerJSON();

$nombreUsuario = trim($datos["usuario"] ?? "");
$password = $datos["password"] ?? "";

if ($nombreUsuario === "" || $password === "") {
    responder(["error" => "Completa todos los campos"], 400);
}

try {

    // Buscar administrador en PostgreSQL
    $consulta = $conexion->prepare("
        SELECT
            id_usuario,
            nombre,
            apellido_paterno,
            apellido_materno,
            usuario,
            password_hash
        FROM usuarios
        WHERE usuario = :usuario
        AND activo = TRUE
    ");

    $consulta->execute([
        ":usuario" => $nombreUsuario
    ]);

    $administrador = $consulta->fetch();

    // Verificar credenciales
    if (
        !$administrador ||
        !password_verify($password, $administrador["password_hash"])
    ) {
        responder([
            "success" => false,
            "error" => "Usuario o contraseña incorrectos"
        ], 401);
    }

    // Crear nueva sesión
    session_regenerate_id(true);

    $_SESSION["usuario_id"] = $administrador["id_usuario"];

    // Responder con los datos actuales de PostgreSQL
    responder([
        "success" => true,
        "usuario" => [
            "id" => $administrador["id_usuario"],
            "nombre" => $administrador["nombre"],
            "apellido_paterno" => $administrador["apellido_paterno"],
            "apellido_materno" => $administrador["apellido_materno"],
            "usuario" => $administrador["usuario"]
        ]
    ]);

} catch (PDOException $e) {

    responder([
        "success" => false,
        "error" => "Error al consultar el administrador."
    ], 500);

}
