
<?php

require_once __DIR__ . "/seguridad.php";
exigirSesion();

$metodo = $_SERVER["REQUEST_METHOD"];

try {

    // CONSULTAR PRODUCTOS
    if ($metodo === "GET") {

        $sql = "
            SELECT
                p.id_producto,
                p.nombre,
                p.descripcion,
                p.id_categoria,
                c.nombre AS categoria,
                p.precio,
                p.stock,
                p.activo
            FROM productos p
            INNER JOIN categorias c
                ON c.id_categoria = p.id_categoria
            ORDER BY p.id_producto
        ";

        $stmt = $conexion->query($sql);

        responder([
            "success" => true,
            "productos" => $stmt->fetchAll()
        ]);
    }

    if ($metodo !== "POST") {
        responder(["error" => "Método no permitido."], 405);
    }

    $datos = obtenerJSON();
    $accion = $datos["accion"] ?? "";

    // VALIDAR DATOS DEL PRODUCTO
    if (in_array($accion, ["crear", "editar"], true)) {

        $nombre = trim($datos["nombre"] ?? "");
        $descripcion = trim($datos["descripcion"] ?? "");

        $idCategoria = filter_var(
            $datos["id_categoria"] ?? null,
            FILTER_VALIDATE_INT
        );

        $precio = $datos["precio"] ?? null;

        if (
            $nombre === "" ||
            !$idCategoria ||
            !is_numeric($precio) ||
            !is_finite((float)$precio) ||
            (float)$precio <= 0
        ) {
            responder(["error" => "Datos del producto inválidos."], 400);
        }

        if (mb_strlen($nombre) > 100 ||
            mb_strlen($descripcion) > 255) {
            responder(["error" => "Los datos exceden el límite permitido."], 400);
        }

        // COMPROBAR QUE LA CATEGORÍA EXISTA Y ESTÉ ACTIVA
        $check = $conexion->prepare("
            SELECT id_categoria
            FROM categorias
            WHERE id_categoria = :id
              AND activa = TRUE
        ");

        $check->execute([":id" => $idCategoria]);

        if (!$check->fetchColumn()) {
            responder([
                "error" => "La categoría no existe o está desactivada."
            ], 400);
        }
    }

    // CREAR PRODUCTO
    if ($accion === "crear") {

        $stmt = $conexion->prepare("
            INSERT INTO productos
                (nombre, descripcion, id_categoria, precio, stock, activo)
            VALUES
                (:nombre, :descripcion, :categoria, :precio, 0, TRUE)
            RETURNING id_producto
        ");

        $stmt->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion ?: null,
            ":categoria" => $idCategoria,
            ":precio" => $precio
        ]);

        responder([
            "success" => true,
            "mensaje" => "Producto registrado correctamente.",
            "id_producto" => $stmt->fetchColumn()
        ], 201);
    }

    // EDITAR PRODUCTO
    if ($accion === "editar") {

        $id = filter_var(
            $datos["id_producto"] ?? null,
            FILTER_VALIDATE_INT
        );

        if (!$id) {
            responder(["error" => "Identificador inválido."], 400);
        }

        $stmt = $conexion->prepare("
            UPDATE productos
            SET nombre = :nombre,
                descripcion = :descripcion,
                id_categoria = :categoria,
                precio = :precio
            WHERE id_producto = :id
        ");

        $stmt->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion ?: null,
            ":categoria" => $idCategoria,
            ":precio" => $precio,
            ":id" => $id
        ]);

        if ($stmt->rowCount() === 0) {
            $check = $conexion->prepare("
                SELECT 1 FROM productos WHERE id_producto = :id
            ");
            $check->execute([":id" => $id]);

            if (!$check->fetchColumn()) {
                responder(["error" => "Producto no encontrado."], 404);
            }
        }

        responder([
            "success" => true,
            "mensaje" => "Producto actualizado correctamente."
        ]);
    }

    // ACTIVAR / DESACTIVAR PRODUCTO
    if ($accion === "estado") {

        $id = filter_var(
            $datos["id_producto"] ?? null,
            FILTER_VALIDATE_INT
        );

        if (!$id) {
            responder(["error" => "Identificador inválido."], 400);
        }

        $stmt = $conexion->prepare("
            UPDATE productos
            SET activo = NOT activo
            WHERE id_producto = :id
        ");

        $stmt->execute([":id" => $id]);

        if ($stmt->rowCount() === 0) {
            responder(["error" => "Producto no encontrado."], 404);
        }

        responder([
            "success" => true,
            "mensaje" => "Estado del producto actualizado."
        ]);
    }

    responder(["error" => "Acción desconocida."], 400);

} catch (PDOException $e) {

    error_log("Error productos.php: " . $e->getMessage());

    responder([
        "error" => "Error al procesar los productos."
    ], 500);
}
